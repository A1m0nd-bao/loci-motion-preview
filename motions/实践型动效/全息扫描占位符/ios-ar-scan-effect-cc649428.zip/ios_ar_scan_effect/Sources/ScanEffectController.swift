import ARKit
import Combine
import Foundation
import RealityKit
import simd

public final class ScanEffectController {
    private weak var arView: ARView?
    private var root = AnchorEntity(world: .zero)
    private var modelGroup = Entity()
    private var bodyEntity: Entity?
    private var faintGridEntity: Entity?
    private var gridEntity: Entity?
    private var groundLineEntity: Entity?
    private var bodyMaterial: CustomMaterial?
    private var faintGridMaterial: Material?
    private var gridMaterial: CustomMaterial?
    private var cancellables = Set<AnyCancellable>()
    private var startTime = CACurrentMediaTime() - 1.2
    private var config = ScanEffectConfig()

    public init() {}

    public func install(in arView: ARView, config: ScanEffectConfig = ScanEffectConfig()) {
        self.arView = arView
        self.config = config

        #if targetEnvironment(simulator)
        root = AnchorEntity(world: SIMD3<Float>(0.0, -0.52, -1.75))
        arView.environment.background = .color(.black)
        installPreviewLighting(in: arView)
        #else
        let sessionConfig = ARWorldTrackingConfiguration()
        sessionConfig.planeDetection = [.horizontal]
        sessionConfig.environmentTexturing = .automatic
        arView.session.run(sessionConfig)

        root = AnchorEntity(plane: .horizontal)
        #endif
        modelGroup.name = "one-meter-foot-aligned-model"
        root.addChild(modelGroup)
        arView.scene.addAnchor(root)

        loadAssets()
        arView.scene.subscribe(to: SceneEvents.Update.self) { [weak self] event in
            self?.update(event.deltaTime)
        }
        .store(in: &cancellables)
    }

    private func loadAssets() {
        guard let bodyURL = Bundle.main.url(forResource: "new_body_model", withExtension: "usdz"),
              let gridURL = Bundle.main.url(forResource: "user_wire_grid", withExtension: "usdz") else {
            assertionFailure("Missing scan effect USDZ assets in the app bundle.")
            return
        }

        do {
            bodyMaterial = try ScanMaterials.makeBodyMaterial(config: config)
            faintGridMaterial = ScanMaterials.makeFaintGridMaterial(config: config)
            gridMaterial = try ScanMaterials.makeGridMaterial(config: config)

            let body = try Entity.load(contentsOf: bodyURL)
            body.name = "scan-body"
            apply(material: bodyMaterial, to: body)
            modelGroup.addChild(body)
            bodyEntity = body

            let faintGrid = try Entity.load(contentsOf: gridURL)
            faintGrid.name = "faint-user-wireframe-inside"
            apply(material: faintGridMaterial, to: faintGrid)
            modelGroup.addChild(faintGrid)
            faintGridEntity = faintGrid

            let grid = try Entity.load(contentsOf: gridURL)
            grid.name = "scan-grid-from-user-wireframe"
            apply(material: gridMaterial, to: grid)
            modelGroup.addChild(grid)
            gridEntity = grid

            fitModelToTargetHeightAndGround(body: body)
            addGroundLine()
        } catch {
            assertionFailure("Failed to load scan assets: \(error)")
        }
    }

    private func fitModelToTargetHeightAndGround(body: Entity) {
        let bounds = body.visualBounds(relativeTo: modelGroup)
        let rawHeight = max(bounds.extents.y, 0.0001)
        let baseScale = config.targetModelHeight / rawHeight
        #if targetEnvironment(simulator)
        let finalScale = baseScale * config.previewScaleMultiplier
        #else
        let finalScale = baseScale
        #endif

        modelGroup.scale = SIMD3<Float>(repeating: finalScale)
        modelGroup.position.y = -bounds.min.y * finalScale
    }

    private func addGroundLine() {
        let mesh = MeshResource.generateBox(
            width: config.groundLineLength,
            height: config.groundLineThickness,
            depth: config.groundLineThickness
        )
        var material = UnlitMaterial(color: .init(red: 0.84, green: 1.0, blue: 0.94, alpha: 0.72))
        material.blending = .transparent(opacity: 0.72)

        let line = ModelEntity(mesh: mesh, materials: [material])
        line.name = "ground-horizon-line-foot-y0"
        line.position = SIMD3<Float>(0.0, config.groundLineThickness * 0.5, 0.0)
        root.addChild(line)
        groundLineEntity = line
    }

    private func installPreviewLighting(in arView: ARView) {
        let keyLight = DirectionalLight()
        keyLight.light.intensity = 1800
        keyLight.light.color = .white
        keyLight.look(at: .zero, from: SIMD3<Float>(-0.6, 1.0, 1.0), relativeTo: nil)
        let lightAnchor = AnchorEntity(world: .zero)
        lightAnchor.addChild(keyLight)
        arView.scene.addAnchor(lightAnchor)
    }

    private func update(_ deltaTime: TimeInterval) {
        let elapsed = Float(CACurrentMediaTime() - startTime)
        let phase = elapsed * config.scanSpeed
        let scanCenter = simd_fract(phase)
        let baseRotation: Float
        #if targetEnvironment(simulator)
        baseRotation = .pi / 2.0
        #else
        baseRotation = 0.0
        #endif
        modelGroup.orientation = simd_quatf(angle: baseRotation, axis: SIMD3<Float>(0.0, 1.0, 0.0))

        bodyMaterial?.custom.value = SIMD4<Float>(
            config.bodyOpacity,
            config.rimStrength,
            0.0,
            0.0
        )
        gridMaterial?.custom.value = SIMD4<Float>(
            scanCenter,
            config.scanHeight,
            config.gridIntensity,
            0.0
        )
        if let bodyMaterial {
            apply(material: bodyMaterial, to: bodyEntity)
        }
        if let gridMaterial {
            apply(material: gridMaterial, to: gridEntity)
        }
    }

    private func apply(material: Material?, to entity: Entity?) {
        guard let material, let entity else { return }

        if let model = entity as? ModelEntity {
            model.model?.materials = [material]
        }

        for child in entity.children {
            apply(material: material, to: child)
        }
    }
}
