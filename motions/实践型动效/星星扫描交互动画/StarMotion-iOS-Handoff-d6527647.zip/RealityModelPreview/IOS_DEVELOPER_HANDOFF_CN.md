# iOS 3D Star Motion Handoff

## 交付内容

这是一个可运行的 iOS RealityKit 示例工程，用来演示 3D 星星模型在 App 内的动效交互。

开发同学可以直接打开：

```text
RealityModelPreview.xcodeproj
```

主要文件：

- `RealityModelPreview/Models/model_with_effect_bounds.usdz`：当前 Demo 使用的 3D 模型文件，内含透明外框约束节点
- `RealityModelPreview/Models/model.usdz`：原始 3D 模型文件备份
- `RealityModelPreview/Models/source.usdc`：原始 usdc 文件备份
- `RealityModelPreview/Effects/Explosion07/`：临时使用的爆开光效 PNG 序列帧
- `RealityModelPreview/ModelStageView.swift`：RealityKit 3D 场景、模型加载、旋转、生长、震动、消失、重生逻辑
- `RealityModelPreview/ContentView.swift`：SwiftUI 容器、点击触发层、序列帧光效播放层

## 当前动效表现

1. 星星出生时从很小的尺寸生长到正常尺寸。
2. 常态下星星沿 Y 轴慢速旋转，并带有轻微上下漂浮。
3. 点击预览区域一次后，星星进入约 3 秒的连续震动状态，并伴随弹性缩放和粒子反馈。
4. 3 秒震动结束后触发完成动效：播放爆开光效序列帧，星星收缩消失。
5. 消失后短暂停顿，然后星星重新出生并再次播放生长动画。

## 临时光效资源

当前消失光效使用 PNG 序列帧，路径：

```text
RealityModelPreview/Effects/Explosion07/
```

序列帧信息：

- 文件名：`explosion_0000.png` 到 `explosion_0039.png`
- 帧数：40 帧
- 播放帧率：30 fps
- 单帧尺寸：1280 x 675
- 透明通道：有
- 文件夹体积：约 6.3MB

这是一版临时交付资源，已经从原始 4096 x 2160 序列帧压缩到移动端预览更合适的尺寸。正式接入时仍建议替换成 Lottie，以进一步减少包体和运行内存压力。

## 关键参数

在 `ModelStageView.swift` 的 `ModelStageConfiguration.demo` 中可以调整：

```swift
static let demo = ModelStageConfiguration(
    modelFileName: "model_with_effect_bounds.usdz",
    modelScale: SIMD3<Float>(repeating: 0.38),
    growthDuration: 1.8,
    idleRotationSpeed: 0.55,
    floatAmplitude: 0.045,
    floatSpeed: 1.35
)
```

参数含义：

- `modelScale`：模型最终展示大小
- `growthDuration`：出生/生长动画时长
- `idleRotationSpeed`：常态旋转速度，目前为 Y 轴旋转
- `floatAmplitude`：上下漂浮幅度
- `floatSpeed`：漂浮速度

## 交互说明

点击触发目前由 `ContentView.swift` 中的透明 SwiftUI 点击层统一发送通知：

```swift
NotificationCenter.default.post(name: .starStageTapped, object: nil)
```

`ModelStageView.swift` 监听 `.starStageTapped`，并执行 `triggerTap()`。

这样做的原因是：RealityKit 的 3D 模型 hit-test 在模型形状复杂、碰撞体不稳定时可能不容易点中。正式项目中如果需要“点模型本身才触发”，开发可以替换成 RealityKit entity hit-test；如果希望交互更稳，可以继续使用当前这种“预览区域触发”的方式。

## 模型轴向

当前模型已经做了展示朝向修正：

```swift
private let modelFacingCorrection =
    simd_quatf(angle: .pi, axis: [0, 0, 1]) *
    simd_quatf(angle: .pi, axis: [0, 1, 0]) *
    simd_quatf(angle: .pi / 2, axis: [1, 0, 0])
```

常态旋转逻辑：

```swift
let faceSpin = simd_quatf(angle: elapsed * configuration.idleRotationSpeed, axis: [0, 1, 0])
modelRoot.orientation = faceSpin * modelFacingCorrection
```

如果替换模型后朝向不对，优先调整 `modelFacingCorrection`。

## 隐形外框约束

为了解决 AR 环境中“星星缩放”和“爆开/Lottie 光效尺寸”不容易同步的问题，当前交付里新增了一个带透明外框的 USDZ：

```text
RealityModelPreview/Models/model_with_effect_bounds.usdz
```

这个文件保留了原星星模型，并额外加入了一个透明立方体节点：

```text
/root/EffectBounds
```

节点信息：

- 类型：USD `Cube`
- 尺寸：`size = 2.4`
- 可见性：`visibility = invisible`
- 材质：透明材质，`opacity = 0`，作为兼容补充
- 用途：作为星星模型和爆开/Lottie 光效共同参考的尺寸约束

建议正式接入 AR 时，程序以 `/root/EffectBounds` 的 bounds 作为统一参考尺寸：星星模型可以继续按设计动效缩放，外部序列帧或 Lottie 光效则根据这个外框做固定比例适配。Demo 中也会在加载后禁用 `EffectBounds`，避免它参与显示或碰撞。

## 开发迁移建议

如果要接入正式 iOS App，可以把以下部分迁移过去：

1. `Models/model_with_effect_bounds.usdz`
2. `ModelStageView.swift` 中的 `ModelStageView` 和 `ModelStageConfiguration`
3. `ContentView.swift` 里的点击触发和 `ImageSequenceOverlay`

正式项目建议保留参数入口，方便设计同学后续调节：

- 生长时长
- 旋转速度
- 点击后连续震动时长
- 点击反馈强度
- 完成动效强度
- 重生等待时间

## 运行环境

- Xcode 26.4.1 已验证
- iOS Simulator 已验证
- RealityKit + SwiftUI
- 最低部署版本：iOS 17.0 simulator 配置
