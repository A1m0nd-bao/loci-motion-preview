import SwiftUI

@main
struct RealityModelPreviewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
