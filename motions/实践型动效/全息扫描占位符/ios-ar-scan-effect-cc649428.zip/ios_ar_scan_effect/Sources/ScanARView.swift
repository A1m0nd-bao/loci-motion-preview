import ARKit
import RealityKit
import SwiftUI

public struct ScanARView: UIViewRepresentable {
    private let config: ScanEffectConfig

    public init(config: ScanEffectConfig = ScanEffectConfig()) {
        self.config = config
    }

    public func makeUIView(context: Context) -> ARView {
        #if targetEnvironment(simulator)
        let arView = ARView(frame: .zero, cameraMode: .nonAR, automaticallyConfigureSession: false)
        #else
        let arView = ARView(frame: .zero)
        #endif
        context.coordinator.install(in: arView, config: config)
        return arView
    }

    public func updateUIView(_ uiView: ARView, context: Context) {}

    public func makeCoordinator() -> ScanEffectController {
        ScanEffectController()
    }
}
