import ARKit
import SceneKit
import SwiftUI

struct GrowthSceneView: UIViewRepresentable {
    let replayToken: UUID

    func makeCoordinator() -> GrowthSceneController {
        GrowthSceneController()
    }

    func makeUIView(context: Context) -> UIView {
        context.coordinator.lastReplayToken = replayToken
        return context.coordinator.makeView()
    }

    func updateUIView(_ uiView: UIView, context: Context) {
        guard context.coordinator.lastReplayToken != replayToken else { return }
        context.coordinator.lastReplayToken = replayToken
        context.coordinator.replay()
    }
}

final class GrowthSceneController: NSObject, ARSCNViewDelegate {
    private enum Metrics {
        static let startScale: Float = 0.07
        static let finalScale: Float = 1.0
        static let belowPlaneOffset: Float = -0.16
        static let growthDuration: TimeInterval = 1.25
        static let portalRiseDuration: TimeInterval = 0.48
        static let portalSettleDuration: TimeInterval = 0.22
        static let characterDelay: TimeInterval = 0.62
        static let portalFinalScale: CGFloat = 0.25
        static let portalOvershootScale: CGFloat = 0.29
        static let outlineDuration: TimeInterval = 1.45
        static let ringDuration: TimeInterval = 1.45
        static let settledScalePulse: CGFloat = 1.035
        static let outlineShellScale: Float = 1.085
        static let previewFocus = SCNVector3(0, 0.36, 0)
    }

    private enum PortalGeometry {
        case energy
        case voxel
    }

    private struct PortalStyle {
        let geometry: PortalGeometry
        let usesAssetModel: Bool
        let rotationY: Float
        let finalScale: CGFloat
        let overshootScale: CGFloat
        let edgeGlow: UIColor
        let edgeCore: UIColor
        let innerDeep: UIColor
        let innerMid: UIColor
        let innerBright: UIColor
        let innerCore: UIColor
        let accentA: UIColor
        let accentB: UIColor
        let outerBlock: UIColor
        let outerTop: UIColor
        let wallDeep: UIColor
        let wallHighlight: UIColor
        let particleLarge: UIColor
        let particleSmall: UIColor
        let glowMultiplier: CGFloat
        let particleScale: Float
        let chipDensity: Int

        static let universalEnergy = PortalStyle(
            geometry: .energy,
            usesAssetModel: false,
            rotationY: 0,
            finalScale: Metrics.portalFinalScale,
            overshootScale: Metrics.portalOvershootScale,
            edgeGlow: UIColor(red: 0.12, green: 0.92, blue: 1.0, alpha: 1),
            edgeCore: UIColor(red: 0.78, green: 1.0, blue: 1.0, alpha: 1),
            innerDeep: UIColor(red: 0.02, green: 0.18, blue: 0.26, alpha: 1),
            innerMid: UIColor(red: 0.04, green: 0.42, blue: 0.54, alpha: 1),
            innerBright: UIColor(red: 0.14, green: 0.78, blue: 0.86, alpha: 1),
            innerCore: UIColor(red: 0.46, green: 0.96, blue: 1.0, alpha: 1),
            accentA: UIColor(red: 0.6, green: 1.0, blue: 0.96, alpha: 1),
            accentB: UIColor(red: 0.18, green: 0.58, blue: 1.0, alpha: 1),
            outerBlock: UIColor(red: 0.08, green: 0.11, blue: 0.13, alpha: 1),
            outerTop: UIColor(red: 0.14, green: 0.18, blue: 0.2, alpha: 1),
            wallDeep: UIColor(red: 0.02, green: 0.2, blue: 0.28, alpha: 1),
            wallHighlight: UIColor(red: 0.08, green: 0.54, blue: 0.66, alpha: 1),
            particleLarge: UIColor(red: 0.38, green: 0.95, blue: 1.0, alpha: 1),
            particleSmall: UIColor(red: 0.2, green: 0.56, blue: 1.0, alpha: 1),
            glowMultiplier: 2.6,
            particleScale: 0.82,
            chipDensity: 6
        )

        static let adaptiveVoxel = PortalStyle(
            geometry: .voxel,
            usesAssetModel: false,
            rotationY: Float.pi / 2,
            finalScale: Metrics.portalFinalScale,
            overshootScale: Metrics.portalOvershootScale,
            edgeGlow: UIColor(red: 0.1, green: 1.0, blue: 0.42, alpha: 1),
            edgeCore: UIColor(red: 0.42, green: 1.0, blue: 0.48, alpha: 1),
            innerDeep: UIColor(red: 0.015, green: 0.16, blue: 0.34, alpha: 1),
            innerMid: UIColor(red: 0.02, green: 0.32, blue: 0.54, alpha: 1),
            innerBright: UIColor(red: 0.06, green: 0.54, blue: 0.66, alpha: 1),
            innerCore: UIColor(red: 0.12, green: 0.82, blue: 0.82, alpha: 1),
            accentA: UIColor(red: 0.18, green: 0.92, blue: 0.82, alpha: 1),
            accentB: UIColor(red: 0.025, green: 0.38, blue: 0.78, alpha: 1),
            outerBlock: UIColor(red: 0.105, green: 0.115, blue: 0.112, alpha: 1),
            outerTop: UIColor(red: 0.155, green: 0.17, blue: 0.165, alpha: 1),
            wallDeep: UIColor(red: 0.018, green: 0.23, blue: 0.29, alpha: 1),
            wallHighlight: UIColor(red: 0.025, green: 0.46, blue: 0.52, alpha: 1),
            particleLarge: UIColor(red: 0.08, green: 0.88, blue: 1.0, alpha: 1),
            particleSmall: UIColor(red: 0.06, green: 0.46, blue: 1.0, alpha: 1),
            glowMultiplier: 2.65,
            particleScale: 1.0,
            chipDensity: 5
        )

        static let hologramBlue = PortalStyle(
            geometry: .energy,
            usesAssetModel: false,
            rotationY: 0,
            finalScale: Metrics.portalFinalScale,
            overshootScale: Metrics.portalOvershootScale,
            edgeGlow: UIColor(red: 0.18, green: 0.76, blue: 1.0, alpha: 1),
            edgeCore: UIColor(red: 0.65, green: 0.92, blue: 1.0, alpha: 1),
            innerDeep: UIColor(red: 0.02, green: 0.08, blue: 0.22, alpha: 1),
            innerMid: UIColor(red: 0.04, green: 0.2, blue: 0.46, alpha: 1),
            innerBright: UIColor(red: 0.08, green: 0.46, blue: 0.72, alpha: 1),
            innerCore: UIColor(red: 0.28, green: 0.82, blue: 1.0, alpha: 1),
            accentA: UIColor(red: 0.42, green: 0.96, blue: 1.0, alpha: 1),
            accentB: UIColor(red: 0.12, green: 0.36, blue: 1.0, alpha: 1),
            outerBlock: UIColor(red: 0.09, green: 0.105, blue: 0.13, alpha: 1),
            outerTop: UIColor(red: 0.145, green: 0.165, blue: 0.2, alpha: 1),
            wallDeep: UIColor(red: 0.02, green: 0.16, blue: 0.32, alpha: 1),
            wallHighlight: UIColor(red: 0.04, green: 0.42, blue: 0.62, alpha: 1),
            particleLarge: UIColor(red: 0.38, green: 0.9, blue: 1.0, alpha: 1),
            particleSmall: UIColor(red: 0.2, green: 0.48, blue: 1.0, alpha: 1),
            glowMultiplier: 2.35,
            particleScale: 0.86,
            chipDensity: 6
        )

        static let warmMagic = PortalStyle(
            geometry: .energy,
            usesAssetModel: false,
            rotationY: 0,
            finalScale: Metrics.portalFinalScale,
            overshootScale: Metrics.portalOvershootScale,
            edgeGlow: UIColor(red: 1.0, green: 0.66, blue: 0.18, alpha: 1),
            edgeCore: UIColor(red: 1.0, green: 0.92, blue: 0.44, alpha: 1),
            innerDeep: UIColor(red: 0.22, green: 0.08, blue: 0.04, alpha: 1),
            innerMid: UIColor(red: 0.46, green: 0.18, blue: 0.05, alpha: 1),
            innerBright: UIColor(red: 0.75, green: 0.34, blue: 0.08, alpha: 1),
            innerCore: UIColor(red: 1.0, green: 0.62, blue: 0.16, alpha: 1),
            accentA: UIColor(red: 1.0, green: 0.82, blue: 0.38, alpha: 1),
            accentB: UIColor(red: 0.86, green: 0.24, blue: 0.16, alpha: 1),
            outerBlock: UIColor(red: 0.13, green: 0.105, blue: 0.09, alpha: 1),
            outerTop: UIColor(red: 0.2, green: 0.165, blue: 0.13, alpha: 1),
            wallDeep: UIColor(red: 0.28, green: 0.1, blue: 0.04, alpha: 1),
            wallHighlight: UIColor(red: 0.62, green: 0.28, blue: 0.06, alpha: 1),
            particleLarge: UIColor(red: 1.0, green: 0.74, blue: 0.28, alpha: 1),
            particleSmall: UIColor(red: 1.0, green: 0.36, blue: 0.18, alpha: 1),
            glowMultiplier: 2.15,
            particleScale: 0.92,
            chipDensity: 7
        )
    }

    private var sceneView: SCNView?
    private var arView: ARSCNView? { sceneView as? ARSCNView }
    private let scene = SCNScene()
    private let placementRoot = SCNNode()
    private let portalStyle = PortalStyle.universalEnergy
    private var portalNodes: [SCNNode] = []
    private var characterRoot: SCNNode?
    private var modelNode: SCNNode?
    private var outlineNode: SCNNode?
    var lastReplayToken: UUID?

    func makeView() -> UIView {
        let view: SCNView

        #if targetEnvironment(simulator)
        let shouldUseAR = false
        #else
        let shouldUseAR = ARWorldTrackingConfiguration.isSupported
        #endif

        if shouldUseAR {
            let arSceneView = ARSCNView(frame: .zero)
            arSceneView.delegate = self
            arSceneView.automaticallyUpdatesLighting = true
            let configuration = ARWorldTrackingConfiguration()
            configuration.planeDetection = [.horizontal]
            arSceneView.session.run(configuration)
            let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
            arSceneView.addGestureRecognizer(tap)
            view = arSceneView
        } else {
            let previewView = SCNView(frame: .zero)
            previewView.allowsCameraControl = true
            view = previewView
        }

        sceneView = view
        view.scene = scene
        view.backgroundColor = UIColor(red: 0.035, green: 0.04, blue: 0.055, alpha: 1)
        view.antialiasingMode = .multisampling4X
        setupScene()
        replay()
        return view
    }

    func replay() {
        placementRoot.removeAllActions()
        placementRoot.childNodes.forEach { $0.removeAllActions() }
        placementRoot.childNodes.forEach { $0.removeFromParentNode() }
        let previewPosition = arView == nil ? SCNVector3Zero : SCNVector3(0, 0, -0.95)
        buildPlacement(at: previewPosition)
        runGrowthAnimation()
    }

    @objc private func handleTap(_ recognizer: UITapGestureRecognizer) {
        guard let arView else { return }
        let point = recognizer.location(in: arView)
        let hits = arView.hitTest(point, types: [.existingPlaneUsingExtent, .estimatedHorizontalPlane])
        guard let hit = hits.first else {
            replay()
            return
        }

        let transform = hit.worldTransform
        let position = SCNVector3(transform.columns.3.x, transform.columns.3.y, transform.columns.3.z)
        placementRoot.removeFromParentNode()
        scene.rootNode.addChildNode(placementRoot)
        buildPlacement(at: position)
        runGrowthAnimation()
    }

    private func setupScene() {
        scene.rootNode.childNodes.forEach { $0.removeFromParentNode() }

        let ambient = SCNLight()
        ambient.type = .ambient
        ambient.intensity = 420
        let ambientNode = SCNNode()
        ambientNode.light = ambient
        scene.rootNode.addChildNode(ambientNode)

        let key = SCNLight()
        key.type = .directional
        key.intensity = 900
        key.castsShadow = true
        let keyNode = SCNNode()
        keyNode.light = key
        keyNode.eulerAngles = SCNVector3(-Float.pi / 3, -Float.pi / 5, 0)
        scene.rootNode.addChildNode(keyNode)

        if arView == nil {
            let camera = SCNCamera()
            camera.wantsHDR = true
            camera.fieldOfView = 42
            let cameraNode = SCNNode()
            cameraNode.camera = camera
            cameraNode.position = SCNVector3(0, 0.95, 3.15)
            cameraNode.look(at: Metrics.previewFocus)
            scene.rootNode.addChildNode(cameraNode)
            sceneView?.pointOfView = cameraNode
            sceneView?.defaultCameraController.target = Metrics.previewFocus

            let grid = SCNPlane(width: 18, height: 18)
            let gridMaterial = SCNMaterial()
            gridMaterial.diffuse.contents = UIColor(red: 0.05, green: 0.46, blue: 0.52, alpha: 1)
            gridMaterial.emission.contents = UIColor(red: 0.01, green: 0.13, blue: 0.16, alpha: 1)
            gridMaterial.isDoubleSided = true
            grid.materials = [gridMaterial]
            let gridNode = SCNNode(geometry: grid)
            gridNode.eulerAngles.x = -Float.pi / 2
            gridNode.position.y = -0.002
            scene.rootNode.addChildNode(gridNode)
        }

        scene.rootNode.addChildNode(placementRoot)
    }

    private func buildPlacement(at position: SCNVector3) {
        placementRoot.position = position
        placementRoot.scale = SCNVector3(1, 1, 1)

        let characterRoot = SCNNode()
        characterRoot.name = "character_root"
        characterRoot.scale = SCNVector3(Metrics.startScale, Metrics.startScale, Metrics.startScale)
        self.characterRoot = characterRoot
        placementRoot.addChildNode(characterRoot)

        let character = loadCharacter()
        character.name = "character"
        normalize(character)
        applyCharacterMaterial(to: character)
        modelNode = character
        characterRoot.addChildNode(character)

        let outline = character.clone()
        outline.name = "outline_shell"
        outline.scale = SCNVector3(
            character.scale.x * Metrics.outlineShellScale,
            character.scale.y * Metrics.outlineShellScale,
            character.scale.z * Metrics.outlineShellScale
        )
        outline.opacity = 0
        applyOutlineMaterial(to: outline)
        outlineNode = outline
        characterRoot.addChildNode(outline)

        addPortalElements()
    }

    private func loadCharacter() -> SCNNode {
        guard let url = Bundle.main.url(forResource: "Character", withExtension: "obj"),
              let characterScene = try? SCNScene(url: url) else {
            return fallbackCharacter()
        }

        let container = SCNNode()
        characterScene.rootNode.childNodes.forEach { container.addChildNode($0.clone()) }
        return container
    }

    private func normalize(_ node: SCNNode) {
        let (minBounds, maxBounds) = node.boundingBox
        let size = SCNVector3(maxBounds.x - minBounds.x, maxBounds.y - minBounds.y, maxBounds.z - minBounds.z)
        let maxDimension = max(size.x, max(size.y, size.z))
        guard maxDimension > 0 else { return }

        let targetHeight: Float = 0.72
        let scale = targetHeight / maxDimension
        node.scale = SCNVector3(scale, scale, scale)
        node.position = SCNVector3(
            -(minBounds.x + size.x * 0.5) * scale,
            -minBounds.y * scale,
            -(minBounds.z + size.z * 0.5) * scale
        )
    }

    private func applyOutlineMaterial(to node: SCNNode) {
        let material = SCNMaterial()
        material.diffuse.contents = UIColor(red: 0.72, green: 0.98, blue: 1.0, alpha: 0.48)
        material.emission.contents = UIColor(red: 0.42, green: 0.86, blue: 1.0, alpha: 1)
        material.transparency = 0.86
        material.blendMode = .add
        material.isDoubleSided = true
        material.writesToDepthBuffer = false
        material.readsFromDepthBuffer = false
        material.lightingModel = .constant

        node.enumerateChildNodes { child, _ in
            child.geometry = child.geometry?.copy() as? SCNGeometry
            child.geometry?.materials = [material]
            child.renderingOrder = 20
        }
    }

    private func applyCharacterMaterial(to node: SCNNode) {
        let textureURL = Bundle.main.url(forResource: "tripo_node_10278c56-1757-4c28-a418-e90ee30cd4d5_material", withExtension: "png")
        let material = SCNMaterial()
        material.diffuse.contents = textureURL
        material.roughness.contents = 0.82
        material.metalness.contents = 0.0
        material.lightingModel = .physicallyBased
        material.isDoubleSided = true

        node.enumerateChildNodes { child, _ in
            if let geometry = child.geometry {
                child.geometry = geometry.copy() as? SCNGeometry
                child.geometry?.materials = [material]
            }
        }
    }

    private func loadPortalAsset() -> SCNNode? {
        guard let url = Bundle.main.url(forResource: "voxel_ground_portal", withExtension: "usdz"),
              let portalScene = try? SCNScene(url: url) else {
            return nil
        }

        let container = SCNNode()
        portalScene.rootNode.childNodes.forEach { container.addChildNode($0.clone()) }
        return container
    }

    private func addPortalElements() {
        portalNodes.removeAll()
        if portalStyle.usesAssetModel, let portal = loadPortalAsset() {
            portal.name = "spawn_portal"
            portal.eulerAngles.y = portalStyle.rotationY
            portal.opacity = 0
            placementRoot.addChildNode(portal)
            portalNodes.append(portal)
            return
        }

        let portal = SCNNode()
        portal.name = "spawn_portal"
        portal.eulerAngles.y = portalStyle.rotationY
        portal.opacity = 0
        placementRoot.addChildNode(portal)
        portalNodes.append(portal)

        if portalStyle.geometry == .energy {
            addEnergyPortalElements(to: portal)
            return
        }

        let cell: Float = 0.1116
        let gap: Float = 0.0094
        let innerCells = makePortalInnerCells()
        let boundaryEdges = makePortalBoundaryEdges(from: innerCells)
        let outerCells = makePortalOuterCells(from: innerCells, boundaryEdges: boundaryEdges)

        for cellPoint in innerCells {
            let normalizedRadius = hypot(Float(cellPoint.x) / 7.2, Float(cellPoint.z) / 5.1)
            let height: Float = (cellPoint.x * 17 + cellPoint.z * 11).isMultiple(of: 3) ? 0.0158 : 0.0086
            let wave = sin(Float(cellPoint.x) * 1.4 + Float(cellPoint.z) * 1.9) + cos(Float(cellPoint.x) * 0.8 - Float(cellPoint.z) * 1.2)
            let material: SCNMaterial
            if normalizedRadius > 0.86 {
                material = wave < 0.8 ? portalMaterial(.innerShadow) : portalMaterial(.innerDeep)
            } else if normalizedRadius < 0.34 && wave > -0.2 {
                material = portalMaterial(.innerCore)
            } else {
                material = wave > 1.05 ? portalMaterial(.innerBright) : wave > -0.45 ? portalMaterial(.innerMid) : portalMaterial(.innerDeep)
            }

            let tile = portalBox(
                name: "portal_inner_tile",
                width: cell - gap,
                height: height,
                length: cell - gap,
                position: SCNVector3(Float(cellPoint.x) * cell, 0.002 + height / 2, Float(cellPoint.z) * cell),
                material: material
            )
            portal.addChildNode(tile)

            addInnerPixelChips(
                to: portal,
                cellPoint: cellPoint,
                cell: cell,
                baseHeight: height,
                normalizedRadius: normalizedRadius
            )
        }

        for cellPoint in outerCells {
            let distance = nearestPortalDistance(from: cellPoint, to: innerCells)
            let height: Float = distance < 1.3 ? 0.0756 : distance < 2.15 ? 0.0518 : 0.0324
            let material = (cellPoint.x * 5 + cellPoint.z * 3).isMultiple(of: 7) ? portalMaterial(.outerTop) : portalMaterial(.outer)
            let block = portalBox(
                name: "portal_outer_block",
                width: cell - gap,
                height: height,
                length: cell - gap,
                position: SCNVector3(Float(cellPoint.x) * cell, height / 2, Float(cellPoint.z) * cell),
                material: material
            )
            portal.addChildNode(block)

            if distance < 2.2 && (cellPoint.x * 19 + cellPoint.z * 23).isMultiple(of: 5) {
                let chip = portalBox(
                    name: "portal_outer_chip",
                    width: cell * 0.68,
                    height: 0.013,
                    length: cell * 0.68,
                    position: SCNVector3(Float(cellPoint.x) * cell, height + 0.0065, Float(cellPoint.z) * cell),
                    material: portalMaterial(.outerTop)
                )
                portal.addChildNode(chip)
            }
        }

        for edge in boundaryEdges {
            let wall = portalEdgeBox(
                name: "portal_inner_wall",
                edge: edge,
                cell: cell,
                thickness: 0.018,
                height: 0.158,
                y: -0.065,
                material: (edge.x + edge.z).isMultiple(of: 2) ? portalMaterial(.wallHighlight) : portalMaterial(.wallDeep)
            )
            portal.addChildNode(wall)

            let glow = portalEdgeBox(
                name: "portal_glow_edge",
                edge: edge,
                cell: cell,
                thickness: 0.0245,
                height: 0.020,
                y: 0.092,
                material: portalMaterial(.edge)
            )
            glow.renderingOrder = 12
            portal.addChildNode(glow)

            if (edge.x + edge.z + edge.dx - edge.dz).isMultiple(of: 2) {
                let core = portalEdgeBox(
                    name: "portal_glow_core",
                    edge: edge,
                    cell: cell,
                    thickness: 0.0085,
                    height: 0.0085,
                    y: 0.109,
                    material: portalMaterial(.edgeCore)
                )
                core.renderingOrder = 14
                portal.addChildNode(core)
            }
        }

        addPortalParticles(to: portal)
    }

    private func addEnergyPortalElements(to portal: SCNNode) {
        let shadow = portalCylinder(
            name: "portal_energy_shadow",
            radius: 0.66,
            height: 0.004,
            y: -0.002,
            material: portalEnergyMaterial(color: portalStyle.innerDeep, alpha: 0.22, emissionMultiplier: 0.35, additive: false)
        )
        shadow.scale.z = 0.72
        portal.addChildNode(shadow)

        let pool = portalCylinder(
            name: "portal_energy_pool",
            radius: 0.55,
            height: 0.006,
            y: 0.004,
            material: portalEnergyMaterial(color: portalStyle.innerMid, alpha: 0.5, emissionMultiplier: 1.1)
        )
        pool.scale.z = 0.72
        pool.renderingOrder = 8
        portal.addChildNode(pool)

        let core = portalCylinder(
            name: "portal_energy_core",
            radius: 0.32,
            height: 0.008,
            y: 0.01,
            material: portalEnergyMaterial(color: portalStyle.innerCore, alpha: 0.42, emissionMultiplier: 1.45)
        )
        core.scale.z = 0.66
        core.renderingOrder = 10
        portal.addChildNode(core)

        let outerRing = portalTorus(
            name: "portal_energy_ring_outer",
            ringRadius: 0.58,
            pipeRadius: 0.018,
            y: 0.028,
            material: portalEnergyMaterial(color: portalStyle.edgeGlow, alpha: 0.92, emissionMultiplier: portalStyle.glowMultiplier)
        )
        outerRing.scale.z = 0.72
        outerRing.renderingOrder = 14
        portal.addChildNode(outerRing)

        let innerRing = portalTorus(
            name: "portal_energy_ring_inner",
            ringRadius: 0.38,
            pipeRadius: 0.006,
            y: 0.034,
            material: portalEnergyMaterial(color: portalStyle.edgeCore, alpha: 0.72, emissionMultiplier: portalStyle.glowMultiplier + 0.2)
        )
        innerRing.scale.z = 0.68
        innerRing.renderingOrder = 15
        portal.addChildNode(innerRing)

        addEnergyArcs(to: portal)
        addEnergyParticles(to: portal)
    }

    private func portalCylinder(name: String, radius: Float, height: Float, y: Float, material: SCNMaterial) -> SCNNode {
        let geometry = SCNCylinder(radius: CGFloat(radius), height: CGFloat(height))
        geometry.radialSegmentCount = 96
        geometry.materials = [material]
        let node = SCNNode(geometry: geometry)
        node.name = name
        node.position.y = y
        return node
    }

    private func portalTorus(name: String, ringRadius: Float, pipeRadius: Float, y: Float, material: SCNMaterial) -> SCNNode {
        let geometry = SCNTorus(ringRadius: CGFloat(ringRadius), pipeRadius: CGFloat(pipeRadius))
        geometry.ringSegmentCount = 128
        geometry.pipeSegmentCount = 12
        geometry.materials = [material]
        let node = SCNNode(geometry: geometry)
        node.name = name
        node.eulerAngles.x = Float.pi / 2
        node.position.y = y
        return node
    }

    private func addEnergyArcs(to portal: SCNNode) {
        let arcAngles: [(Float, Float, Float)] = [
            (0.2, 0.54, 0.16),
            (1.72, 0.48, 0.13),
            (3.08, 0.56, 0.18),
            (4.62, 0.42, 0.12)
        ]

        for (index, arc) in arcAngles.enumerated() {
            let node = portalDash(
                name: "portal_energy_arc",
                width: arc.1,
                length: 0.026,
                radius: 0.58,
                angle: arc.0,
                y: 0.048 + Float(index % 2) * 0.006,
                material: portalEnergyMaterial(
                    color: index.isMultiple(of: 2) ? portalStyle.edgeCore : portalStyle.accentA,
                    alpha: CGFloat(arc.2 + 0.68),
                    emissionMultiplier: portalStyle.glowMultiplier + 0.35
                )
            )
            node.renderingOrder = 18
            portal.addChildNode(node)
        }

        for index in 0..<8 {
            let angle = Float(index) * (Float.pi * 2 / 8) + 0.18
            let node = portalDash(
                name: "portal_energy_tick",
                width: 0.08,
                length: 0.016,
                radius: 0.45 + Float(index % 2) * 0.08,
                angle: angle,
                y: 0.043,
                material: portalEnergyMaterial(color: portalStyle.accentB, alpha: 0.54, emissionMultiplier: 1.6)
            )
            node.renderingOrder = 16
            portal.addChildNode(node)
        }
    }

    private func portalDash(name: String, width: Float, length: Float, radius: Float, angle: Float, y: Float, material: SCNMaterial) -> SCNNode {
        let geometry = SCNBox(width: CGFloat(width), height: 0.008, length: CGFloat(length), chamferRadius: 0.012)
        geometry.materials = [material]
        let node = SCNNode(geometry: geometry)
        node.name = name
        node.position = SCNVector3(cos(angle) * radius, y, sin(angle) * radius * 0.72)
        node.eulerAngles.y = -angle
        return node
    }

    private func addEnergyParticles(to portal: SCNNode) {
        let particles: [(Float, Float, Float, Float)] = [
            (-0.42, 0.16, -0.28, 0.022), (-0.24, 0.28, 0.34, 0.016), (0.08, 0.2, -0.4, 0.019),
            (0.3, 0.34, 0.22, 0.024), (0.48, 0.18, -0.08, 0.014), (-0.54, 0.26, 0.1, 0.017),
            (0.0, 0.42, 0.2, 0.018), (0.18, 0.12, 0.46, 0.013), (-0.16, 0.12, -0.48, 0.013)
        ]

        for (index, particle) in particles.enumerated() {
            let geometry = SCNSphere(radius: CGFloat(particle.3 * portalStyle.particleScale))
            geometry.segmentCount = 16
            geometry.materials = [
                portalEnergyMaterial(
                    color: index.isMultiple(of: 2) ? portalStyle.particleLarge : portalStyle.particleSmall,
                    alpha: 0.82,
                    emissionMultiplier: 1.8
                )
            ]
            let node = SCNNode(geometry: geometry)
            node.name = "portal_particle"
            node.position = SCNVector3(particle.0, particle.1, particle.2)
            node.renderingOrder = 20
            portal.addChildNode(node)
            portalNodes.append(node)
        }
    }

    private func portalEnergyMaterial(color: UIColor, alpha: CGFloat, emissionMultiplier: CGFloat, additive: Bool = true) -> SCNMaterial {
        let material = SCNMaterial()
        material.diffuse.contents = color.withAlphaComponent(alpha)
        material.emission.contents = color.emissionColor(multiplier: emissionMultiplier)
        material.transparency = alpha
        material.blendMode = additive ? .add : .alpha
        material.lightingModel = .constant
        material.isDoubleSided = true
        material.writesToDepthBuffer = false
        material.readsFromDepthBuffer = true
        return material
    }

    private struct PortalCell: Hashable {
        let x: Int
        let z: Int
    }

    private struct PortalEdge {
        let x: Int
        let z: Int
        let dx: Int
        let dz: Int
    }

    private enum PortalMaterialRole {
        case outer
        case outerTop
        case innerDeep
        case innerMid
        case innerBright
        case innerCore
        case innerShadow
        case pixelLight
        case pixelGreen
        case pixelBlue
        case wallDeep
        case wallHighlight
        case edge
        case edgeCore
        case particle
        case particleSmall
    }

    private func makePortalInnerCells() -> Set<PortalCell> {
        let rows: [Int: ClosedRange<Int>] = [
            -5: -2...2,
            -4: -5...4,
            -3: -6...5,
            -2: -7...6,
            -1: -7...7,
            0: -7...7,
            1: -6...6,
            2: -6...5,
            3: -5...5,
            4: -4...4,
            5: -2...3
        ]
        let notches: Set<PortalCell> = [
            PortalCell(x: -7, z: -1), PortalCell(x: -6, z: -3), PortalCell(x: -5, z: 4),
            PortalCell(x: -4, z: -4), PortalCell(x: -2, z: 5), PortalCell(x: 1, z: -5),
            PortalCell(x: 3, z: 5), PortalCell(x: 5, z: 3), PortalCell(x: 6, z: -2),
            PortalCell(x: 7, z: 0)
        ]
        var cells = Set<PortalCell>()
        for (z, range) in rows {
            for x in range {
                let cell = PortalCell(x: x, z: z)
                if !notches.contains(cell) {
                    cells.insert(cell)
                }
            }
        }
        return cells
    }

    private func makePortalBoundaryEdges(from innerCells: Set<PortalCell>) -> [PortalEdge] {
        var edges: [PortalEdge] = []
        let directions = [(1, 0), (-1, 0), (0, 1), (0, -1)]
        for cell in innerCells {
            for direction in directions {
                let neighbor = PortalCell(x: cell.x + direction.0, z: cell.z + direction.1)
                if !innerCells.contains(neighbor) {
                    edges.append(PortalEdge(x: cell.x, z: cell.z, dx: direction.0, dz: direction.1))
                }
            }
        }
        return edges
    }

    private func makePortalOuterCells(from innerCells: Set<PortalCell>, boundaryEdges: [PortalEdge]) -> Set<PortalCell> {
        let extras: Set<PortalCell> = [
            PortalCell(x: -9, z: -3), PortalCell(x: -9, z: 0), PortalCell(x: -8, z: 3),
            PortalCell(x: -7, z: 5), PortalCell(x: -5, z: -6), PortalCell(x: -3, z: 6),
            PortalCell(x: 0, z: 7), PortalCell(x: 3, z: 6), PortalCell(x: 6, z: 5),
            PortalCell(x: 8, z: 2), PortalCell(x: 9, z: -1), PortalCell(x: 8, z: -4),
            PortalCell(x: 5, z: -6), PortalCell(x: 1, z: -7), PortalCell(x: -2, z: -7),
            PortalCell(x: -6, z: -5)
        ]
        var outerCells = Set<PortalCell>()
        for edge in boundaryEdges {
            for ring in 1...3 {
                let cell = PortalCell(x: edge.x + edge.dx * ring, z: edge.z + edge.dz * ring)
                if !innerCells.contains(cell), (-10...10).contains(cell.x), (-8...8).contains(cell.z) {
                    outerCells.insert(cell)
                }
            }
        }
        outerCells.formUnion(extras)
        return outerCells.filter { cell in
            nearestPortalDistance(from: cell, to: innerCells) < 3.25 || extras.contains(cell)
        }
    }

    private func nearestPortalDistance(from cell: PortalCell, to innerCells: Set<PortalCell>) -> Float {
        innerCells.reduce(Float.greatestFiniteMagnitude) { current, inner in
            min(current, hypot(Float(cell.x - inner.x), Float(cell.z - inner.z)))
        }
    }

    private func portalBox(name: String, width: Float, height: Float, length: Float, position: SCNVector3, material: SCNMaterial) -> SCNNode {
        let geometry = SCNBox(width: CGFloat(width), height: CGFloat(height), length: CGFloat(length), chamferRadius: 0.0015)
        geometry.materials = [material]
        let node = SCNNode(geometry: geometry)
        node.name = name
        node.position = position
        return node
    }

    private func portalEdgeBox(
        name: String,
        edge: PortalEdge,
        cell: Float,
        thickness: Float,
        height: Float,
        y: Float,
        material: SCNMaterial
    ) -> SCNNode {
        if edge.dx != 0 {
            return portalBox(
                name: name,
                width: thickness,
                height: height,
                length: cell * 0.92,
                position: SCNVector3((Float(edge.x) + 0.5 * Float(edge.dx)) * cell, y, Float(edge.z) * cell),
                material: material
            )
        } else {
            return portalBox(
                name: name,
                width: cell * 0.92,
                height: height,
                length: thickness,
                position: SCNVector3(Float(edge.x) * cell, y, (Float(edge.z) + 0.5 * Float(edge.dz)) * cell),
                material: material
            )
        }
    }

    private func addInnerPixelChips(to portal: SCNNode, cellPoint: PortalCell, cell: Float, baseHeight: Float, normalizedRadius: Float) {
        let chipRule = positiveModulo(cellPoint.x * 13 + cellPoint.z * 7, portalStyle.chipDensity)
        guard chipRule == 0 || chipRule == 2 || normalizedRadius < 0.42 else { return }

        let chipCount = normalizedRadius < 0.42 && chipRule != 1 ? 2 : 1
        let widths: [Float] = [0.22, 0.30, 0.38, 0.48]
        let depths: [Float] = [0.20, 0.28, 0.36, 0.46]
        let offsets: [Float] = [-0.26, -0.12, 0.12, 0.26]
        for index in 0..<chipCount {
            let seed = abs(cellPoint.x * 41 + cellPoint.z * 67 + index * 13)
            let width = cell * widths[seed % widths.count]
            let depth = cell * depths[(seed / 3) % depths.count]
            let offsetX = offsets[(seed / 5) % offsets.count] * cell
            let offsetZ = offsets[(seed / 7) % offsets.count] * cell
            let material: SCNMaterial
            if normalizedRadius < 0.34 {
                material = portalMaterial(.pixelLight)
            } else if chipRule == 0 && cellPoint.z > 0 {
                material = portalMaterial(.pixelGreen)
            } else if chipRule == 2 && cellPoint.x < 2 {
                material = portalMaterial(.pixelBlue)
            } else {
                material = portalMaterial(.innerBright)
            }

            let chip = portalBox(
                name: "portal_inner_pixel_chip",
                width: width,
                height: 0.005,
                length: depth,
                position: SCNVector3(
                    Float(cellPoint.x) * cell + offsetX,
                    0.002 + baseHeight + 0.006 + Float(index) * 0.002,
                    Float(cellPoint.z) * cell + offsetZ
                ),
                material: material
            )
            portal.addChildNode(chip)
        }

        if normalizedRadius > 0.72 && (cellPoint.x * 5 - cellPoint.z * 9).isMultiple(of: 4) {
            let inset = cell * 0.56
            let shadow = portalBox(
                name: "portal_inner_shadow_inset",
                width: inset,
                height: 0.004,
                length: inset,
                position: SCNVector3(Float(cellPoint.x) * cell, 0.002 + baseHeight + 0.004, Float(cellPoint.z) * cell),
                material: portalMaterial(.innerShadow)
            )
            portal.addChildNode(shadow)
        }
    }

    private func addPortalParticles(to portal: SCNNode) {
        let particles: [(Float, Float, Float, Float)] = [
            (-0.88, 0.32, -0.45, 0.07), (-0.68, 0.42, -0.56, 0.035), (-0.56, 0.22, 0.58, 0.052),
            (-0.42, 0.52, 0.42, 0.068), (-0.24, 0.26, -0.72, 0.038), (-0.08, 0.48, 0.68, 0.048),
            (0.18, 0.28, -0.62, 0.054), (0.34, 0.55, 0.50, 0.04), (0.56, 0.34, -0.42, 0.074),
            (0.78, 0.42, 0.32, 0.058), (0.94, 0.22, -0.18, 0.045), (-1.03, 0.18, 0.08, 0.042),
            (1.08, 0.28, 0.08, 0.086), (-0.98, 0.46, 0.34, 0.052), (0.04, 0.58, -0.16, 0.04),
            (0.66, 0.18, 0.64, 0.032), (-0.18, 0.16, 0.82, 0.032), (0.88, 0.50, -0.52, 0.036)
        ]

        for (index, particle) in particles.enumerated() {
            let material = particle.3 <= 0.045 ? portalMaterial(.particleSmall) : portalMaterial(.particle)
            let size = particle.3 * portalStyle.particleScale
            let node = portalBox(
                name: "portal_particle",
                width: size,
                height: size,
                length: size,
                position: SCNVector3(particle.0, particle.1, particle.2),
                material: material
            )
            node.eulerAngles.y = Float(index % 5) * 0.18
            portal.addChildNode(node)
            portalNodes.append(node)
        }
    }

    private func positiveModulo(_ value: Int, _ divisor: Int) -> Int {
        let result = value % divisor
        return result >= 0 ? result : result + divisor
    }

    private func portalMaterial(_ role: PortalMaterialRole) -> SCNMaterial {
        let material = SCNMaterial()
        material.isDoubleSided = true
        material.roughness.contents = 0.72
        material.metalness.contents = 0.0

        switch role {
        case .outer:
            material.diffuse.contents = portalStyle.outerBlock
        case .outerTop:
            material.diffuse.contents = portalStyle.outerTop
        case .innerDeep:
            material.diffuse.contents = portalStyle.innerDeep
            material.emission.contents = portalStyle.innerDeep.emissionColor(multiplier: 0.75)
        case .innerMid:
            material.diffuse.contents = portalStyle.innerMid
            material.emission.contents = portalStyle.innerMid.emissionColor(multiplier: 0.92)
        case .innerBright:
            material.diffuse.contents = portalStyle.innerBright
            material.emission.contents = portalStyle.innerBright.emissionColor(multiplier: 1.08)
        case .innerCore:
            material.diffuse.contents = portalStyle.innerCore
            material.emission.contents = portalStyle.innerCore.emissionColor(multiplier: 1.25)
        case .innerShadow:
            material.diffuse.contents = portalStyle.innerDeep.darker(by: 0.58)
            material.emission.contents = portalStyle.innerDeep.emissionColor(multiplier: 0.38)
        case .pixelLight:
            material.diffuse.contents = portalStyle.accentA
            material.emission.contents = portalStyle.accentA.emissionColor(multiplier: 1.18)
        case .pixelGreen:
            material.diffuse.contents = portalStyle.edgeGlow
            material.emission.contents = portalStyle.edgeGlow.emissionColor(multiplier: 0.74)
        case .pixelBlue:
            material.diffuse.contents = portalStyle.accentB
            material.emission.contents = portalStyle.accentB.emissionColor(multiplier: 1.04)
        case .wallDeep:
            material.diffuse.contents = portalStyle.wallDeep
            material.emission.contents = portalStyle.wallDeep.emissionColor(multiplier: 1.32)
        case .wallHighlight:
            material.diffuse.contents = portalStyle.wallHighlight
            material.emission.contents = portalStyle.wallHighlight.emissionColor(multiplier: 1.55)
        case .edge:
            material.diffuse.contents = portalStyle.edgeGlow
            material.emission.contents = portalStyle.edgeGlow.emissionColor(multiplier: portalStyle.glowMultiplier)
            material.blendMode = .add
            material.lightingModel = .constant
        case .edgeCore:
            material.diffuse.contents = portalStyle.edgeCore
            material.emission.contents = portalStyle.edgeCore.emissionColor(multiplier: portalStyle.glowMultiplier + 0.4)
            material.blendMode = .add
            material.lightingModel = .constant
        case .particle:
            material.diffuse.contents = portalStyle.particleLarge
            material.emission.contents = portalStyle.particleLarge.emissionColor(multiplier: 1.7)
        case .particleSmall:
            material.diffuse.contents = portalStyle.particleSmall
            material.emission.contents = portalStyle.particleSmall.emissionColor(multiplier: 1.42)
        }

        return material
    }

    private func runGrowthAnimation() {
        guard let characterRoot else { return }

        characterRoot.position.y += Metrics.belowPlaneOffset
        let characterDelay = SCNAction.wait(duration: Metrics.characterDelay)
        let firstRise = SCNAction.moveBy(x: 0, y: CGFloat(-Metrics.belowPlaneOffset) * 0.82, z: 0, duration: Metrics.growthDuration * 0.58)
        firstRise.timingMode = .easeOut
        let finalRise = SCNAction.moveBy(x: 0, y: CGFloat(-Metrics.belowPlaneOffset) * 0.18, z: 0, duration: Metrics.growthDuration * 0.42)
        finalRise.timingMode = .easeInEaseOut
        let moveUp = SCNAction.sequence([firstRise, finalRise])

        let firstScale = SCNAction.scale(to: 0.88, duration: Metrics.growthDuration * 0.54)
        firstScale.timingMode = .easeOut
        let finalScale = SCNAction.scale(to: CGFloat(Metrics.finalScale), duration: Metrics.growthDuration * 0.46)
        finalScale.timingMode = .easeInEaseOut
        let scaleUp = SCNAction.sequence([firstScale, finalScale])
        let settle = SCNAction.sequence([
            SCNAction.scale(to: Metrics.settledScalePulse, duration: 0.12),
            SCNAction.scale(to: 1.0, duration: 0.16)
        ])
        characterRoot.runAction(.sequence([characterDelay, .group([moveUp, scaleUp]), settle]))

        outlineNode?.runAction(.sequence([
            characterDelay,
            .fadeOpacity(to: 1.0, duration: 0.12),
            .repeat(.sequence([
                .fadeOpacity(to: 0.58, duration: 0.24),
                .fadeOpacity(to: 1.0, duration: 0.24)
            ]), count: 4),
            .fadeOut(duration: 0.55)
        ]))

        let portalNode = placementRoot.childNodes.first { $0.name == "spawn_portal" }
        portalNode?.position.y = -0.1
        portalNode?.scale = SCNVector3(0.2, 0.02, 0.2)
        portalNode?.runAction(.sequence([
            .group([
                .fadeOpacity(to: 1.0, duration: 0.08),
                .move(to: SCNVector3(0, 0, 0), duration: Metrics.portalRiseDuration),
                .scale(to: portalStyle.overshootScale, duration: Metrics.portalRiseDuration)
            ]),
            .scale(to: portalStyle.finalScale, duration: Metrics.portalSettleDuration),
            .wait(duration: Metrics.characterDelay + Metrics.growthDuration * 0.88),
            .fadeOut(duration: 0.42),
            .removeFromParentNode()
        ]))

        portalNode?.enumerateChildNodes { node, _ in
            if node.name?.hasPrefix("portal_glow_edge") == true || node.name?.hasPrefix("portal_glow_core") == true {
                let pulse = SCNAction.repeat(.sequence([
                    .fadeOpacity(to: 0.55, duration: 0.26),
                    .fadeOpacity(to: 1.0, duration: 0.26)
                ]), count: 4)
                node.runAction(pulse)
            } else if node.name?.hasPrefix("portal_energy_ring") == true || node.name?.hasPrefix("portal_energy_arc") == true {
                let spin = SCNAction.repeatForever(.rotateBy(x: 0, y: CGFloat.pi * 2, z: 0, duration: node.name?.hasPrefix("portal_energy_arc") == true ? 1.3 : 2.4))
                node.runAction(spin)
                let pulse = SCNAction.repeat(.sequence([
                    .fadeOpacity(to: 0.5, duration: 0.28),
                    .fadeOpacity(to: 1.0, duration: 0.34)
                ]), count: 4)
                node.runAction(pulse)
            } else if node.name?.hasPrefix("portal_energy_core") == true || node.name?.hasPrefix("portal_energy_pool") == true {
                let pulse = SCNAction.repeat(.sequence([
                    .scale(to: 1.04, duration: 0.32),
                    .scale(to: 1.0, duration: 0.32)
                ]), count: 4)
                pulse.timingMode = .easeInEaseOut
                node.runAction(pulse)
            } else if node.name?.hasPrefix("portal_particle") == true {
                let startY = node.position.y
                let drift = SCNAction.repeatForever(.sequence([
                    .move(to: SCNVector3(node.position.x, startY + 0.035, node.position.z), duration: 0.82),
                    .move(to: SCNVector3(node.position.x, startY - 0.012, node.position.z), duration: 0.76)
                ]))
                drift.timingMode = .easeInEaseOut
                node.runAction(drift)
            }
        }
    }

    private func fallbackCharacter() -> SCNNode {
        let container = SCNNode()
        let bodyMaterial = SCNMaterial()
        bodyMaterial.diffuse.contents = UIColor(red: 0.35, green: 0.62, blue: 0.92, alpha: 1)
        bodyMaterial.roughness.contents = 0.75

        let body = SCNNode(geometry: SCNBox(width: 0.28, height: 0.45, length: 0.18, chamferRadius: 0.01))
        body.geometry?.materials = [bodyMaterial]
        body.position.y = 0.36
        container.addChildNode(body)

        let head = SCNNode(geometry: SCNBox(width: 0.24, height: 0.22, length: 0.22, chamferRadius: 0.012))
        head.geometry?.materials = [bodyMaterial]
        head.position.y = 0.72
        container.addChildNode(head)
        return container
    }
}

private extension UIColor {
    func emissionColor(multiplier: CGFloat) -> UIColor {
        var red: CGFloat = 0
        var green: CGFloat = 0
        var blue: CGFloat = 0
        var alpha: CGFloat = 0
        getRed(&red, green: &green, blue: &blue, alpha: &alpha)
        return UIColor(
            red: red * multiplier,
            green: green * multiplier,
            blue: blue * multiplier,
            alpha: alpha
        )
    }

    func darker(by multiplier: CGFloat) -> UIColor {
        var red: CGFloat = 0
        var green: CGFloat = 0
        var blue: CGFloat = 0
        var alpha: CGFloat = 0
        getRed(&red, green: &green, blue: &blue, alpha: &alpha)
        return UIColor(
            red: red * multiplier,
            green: green * multiplier,
            blue: blue * multiplier,
            alpha: alpha
        )
    }
}
