# iOS AR 开发交接说明

这个包是给 iOS AR 开发接入用的。核心结论先写清楚：

**不要把这个效果当成“一个 USDZ 文件就能完整实现”。**  
USDZ 只负责承载模型。青绿色半透明、简单边缘辉光、扫描区域、发光网格，都应该由 iOS App 里的 RealityKit / Metal 运行时代码实现。

## 文件说明

- `Assets/new_body_model.usdz`  
  由 `/Users/baotianrong/Downloads/new.usdc` 转换而来，并已把引用贴图一起打包，供 iOS / RealityKit 直接加载。

- `Assets/user_wire_grid.usdz`  
  由用户提供的线框源资产转换而来。当前 iOS 示例使用这个作为扫描时露出的网格，不再使用程序生成的模型边缘网格。

- `Sources/ScanARView.swift`  
  SwiftUI 可直接挂载的 RealityKit AR 视图。

- `Sources/ScanEffectController.swift`  
  负责加载 USDZ、应用材质、把模型高度自动限制到 1m、将脚底对齐到 AR 平面 y=0，并驱动从下到上的扫描动画。

- `Sources/ScanMaterials.swift`  
  RealityKit 材质配置。

- `Sources/ScanEffectShaders.metal`  
  Metal shader，包含主体半透明、类菲涅耳边缘、扫描区域网格显隐。

## 推荐接入链路

可以直接打开 `ScanEffectARApp.xcodeproj` 查看最小示例工程。

1. 把 `Assets` 里的两个 USDZ 加入 Xcode 工程，并勾选 app target。
2. 把 `Sources` 里的 Swift 和 Metal 文件加入 app target。
3. SwiftUI 页面里直接使用：

```swift
ScanARView()
```

4. 如果项目已经有自己的 `ARView`，则使用：

```swift
let controller = ScanEffectController()
controller.install(in: arView)
```

5. 在真机 AR 场景测试，不要只用 macOS Quick Look 判断最终效果。

## 已做的验证

我已经用本机 Xcode 26.4.1 做过 iOS Simulator SDK 编译校验：

```sh
xcodebuild -project ScanEffectARApp.xcodeproj -scheme ScanEffectAR -sdk iphonesimulator -configuration Debug CODE_SIGNING_ALLOWED=NO build
```

结果：`BUILD SUCCEEDED`。

这只能证明 Swift / RealityKit / Metal shader 工程编译通过。AR 相机、真实机型上的亮度、发光强度、扫描速度，仍然必须在 iPhone/iPad 真机上调。

## 给开发的关键提醒

- Quick Look 不等于最终渲染器。
- 当前网格来自用户提供的线框资产，iOS 端只负责用 shader 按扫描高度裁切显隐，不应该重新生成另一套线框。
- 不建议用高反光/低 roughness 去模拟菲涅耳，那会变成塑料反光，不是你要的发光边缘。
- 当前版本优先保证透明主体和扫描线框可见，辉光只做最简单的材质自发光，不使用外壳，也不使用强 bloom。
- 模型不是直接使用原始 pivot 放置，而是运行时读取主体包围盒：按 `targetModelHeight = 1.0` 缩放，并用包围盒最低点把脚底对齐到地平线/AR 平面。
- 地平线由 `ground-horizon-line-foot-y0` 这个细线实体提供，位于根节点 y=0，用于确认脚底贴地；正式产品如果不需要可隐藏或降低透明度。
- 如果真机里主体看起来不够翠绿，优先调 `ScanEffectShaders.metal` 里的 `bodyColor` 和 `bodyColor * 0.42h` 这段主体青绿色 emissive 填充；扫描线是独立的 `scanGridSurface`，两者不是同一套颜色表现。
- 如果后续仍要“外溢模糊”的强辉光，需要单独加 bloom/后处理；单靠材质 emissive 只能让表面变亮，不能让光晕扩散到模型外。
- 如果项目限制为“只能打开普通 USDZ”，那只能做低保真效果，无法完整还原现在的扫描视觉。
