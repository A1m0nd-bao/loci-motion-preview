# Web v1

打开根目录的「研发先读.md」，然后阅读 web-components/USAGE.md。
此目录来自已提交 Web 版本，移除了历史试验页和不随包交付的旧同步图库条目。组件源码未修改。
