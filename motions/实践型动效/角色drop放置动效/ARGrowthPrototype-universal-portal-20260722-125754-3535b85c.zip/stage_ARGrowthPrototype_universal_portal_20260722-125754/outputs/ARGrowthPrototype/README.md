# AR Growth Prototype

This Xcode prototype focuses on the placement animation only:

- The supplied GLB character was converted into `Character.obj` with its texture and copied as app bundle resources.
- On an AR-capable iPhone or iPad, tap a detected horizontal surface to replay the growth effect at that point.
- In Simulator, the app falls back to a camera-controlled SceneKit preview plane so the timing, scale, ground rings, and outline glow can still be reviewed.

Open:

```sh
open ARGrowthPrototype.xcodeproj
```

Build verification used:

```sh
xcodebuild -project ARGrowthPrototype.xcodeproj -scheme ARGrowthPrototype -configuration Debug -destination 'platform=iOS Simulator,name=iPhone 17 Pro,OS=26.4.1' build
```

Main tuning file:

```text
ARGrowthPrototype/GrowthSceneView.swift
```

Useful parameters are in `GrowthSceneController.Metrics`:

- `startScale`: initial tiny model scale.
- `belowPlaneOffset`: how far below the surface the model starts.
- `growthDuration`: grow-up duration.
- `ringDuration`: ground energy ring expansion speed.
- `settledScalePulse`: the small overshoot after growth.

The outline flash is made by cloning the character, scaling the clone slightly larger, applying an additive emissive material, and fading its opacity in pulses during growth.
