Place the 3D model here.

Recommended format for iOS RealityKit:
- `.usdz` preferred
- `.reality` also works
- `.glb`, `.gltf`, `.fbx`, `.obj` should be converted to `.usdz` before app integration

Current files:

- `model_with_effect_bounds.usdz`: current demo model. It includes the star plus a transparent bounds cube named `/root/EffectBounds`.
- `model.usdz`: original star model backup.
- `source.usdc`: source model backup.

`/root/EffectBounds` is intended as a shared size reference for AR integration, so the app can align the star model and the explosion/Lottie effect against the same constraint box.

After adding a model file, set `modelFileName` in `ModelStageView.swift` / `ModelStageConfiguration.demo`.
