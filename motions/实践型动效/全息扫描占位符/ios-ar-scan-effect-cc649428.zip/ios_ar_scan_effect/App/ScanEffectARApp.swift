import SwiftUI

@main
struct ScanEffectARApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
