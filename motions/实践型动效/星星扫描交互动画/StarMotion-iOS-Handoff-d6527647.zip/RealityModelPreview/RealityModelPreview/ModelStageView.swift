import RealityKit
import SwiftUI
import UIKit

struct ModelStageConfiguration {
    var modelFileName: String?
    var modelScale: SIMD3<Float>
    var growthDuration: TimeInterval
    var idleRotationSpeed: Float
    var floatAmplitude: Float
    var floatSpeed: Float

    static let demo = ModelStageConfiguration(
        modelFileName: "model_with_effect_bounds.usdz",
        modelScale: SIMD3<Float>(repeating: 0.38),
        growthDuration: 1.8,
        idleRotationSpeed: 0.55,
        floatAmplitude: 0.045,
        floatSpeed: 1.35
    )
}

struct ModelStageView: UIViewRepresentable {
    let configuration: ModelStageConfiguration

    func makeCoordinator() -> Coordinator {
        Coordinator(configuration: configuration)
    }

    func makeUIView(context: Context) -> ARView {
        let view = ARView(frame: .zero, cameraMode: .nonAR, automaticallyConfigureSession: false)
        view.environment.background = .color(.init(red: 0.04, green: 0.045, blue: 0.055, alpha: 1.0))
        view.renderOptions.insert(.disableMotionBlur)
        view.renderOptions.insert(.disableGroundingShadows)
        context.coordinator.installScene(in: view)

        let tap = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handleTap(_:)))
        view.addGestureRecognizer(tap)
        return view
    }

    func updateUIView(_ uiView: ARView, context: Context) {}

    final class Coordinator: NSObject {
        private let configuration: ModelStageConfiguration
        private weak var arView: ARView?
        private let anchor = AnchorEntity(world: .zero)
        private var modelRoot = Entity()
        private var halo = ModelEntity()
        private var flashCore = ModelEntity()
        private var scanRing = ModelEntity()
        private var sparkleGroup = Entity()
        private var burstPieces: [ModelEntity] = []
        private var displayLink: CADisplayLink?
        private var startTime = CACurrentMediaTime()
        private var lifecycleStartTime = CACurrentMediaTime()
        private var baseY: Float = 0
        private var interactionUntil: CFTimeInterval = 0
        private var interactionStart: CFTimeInterval = -10
        private var completionShakeStart: CFTimeInterval = -10
        private var nextShakeHapticTime: CFTimeInterval = 0
        private var disappearStart: CFTimeInterval = -10
        private let completionShakeDuration: Float = 3.0
        private let disappearDuration: Float = 0.72
        private let rebirthPause: Float = 0.32
        private var tapObserver: NSObjectProtocol?
        private let modelFacingCorrection =
            simd_quatf(angle: .pi, axis: [0, 0, 1]) *
            simd_quatf(angle: .pi, axis: [0, 1, 0]) *
            simd_quatf(angle: .pi / 2, axis: [1, 0, 0])

        init(configuration: ModelStageConfiguration) {
            self.configuration = configuration
            super.init()
        }

        deinit {
            displayLink?.invalidate()
            if let tapObserver {
                NotificationCenter.default.removeObserver(tapObserver)
            }
        }

        func installScene(in view: ARView) {
            arView = view
            view.scene.addAnchor(anchor)

            configureCamera()
            configureLighting()
            installModel()
            installHalo()
            installFlashCore()
            installSparkles()
            installTapObserver()
            startDisplayLink()
        }

        @objc func handleTap(_ gesture: UITapGestureRecognizer) {
            triggerTap()
        }

        private func installTapObserver() {
            tapObserver = NotificationCenter.default.addObserver(
                forName: .starStageTapped,
                object: nil,
                queue: .main
            ) { [weak self] _ in
                self?.triggerTap()
            }
        }

        private func triggerTap() {
            guard disappearStart < 0, completionShakeStart < 0 else { return }

            let now = CACurrentMediaTime()
            interactionStart = now
            interactionUntil = now + CFTimeInterval(completionShakeDuration)
            completionShakeStart = now
            nextShakeHapticTime = now
            UIImpactFeedbackGenerator(style: .medium).impactOccurred(intensity: 0.5)
        }

        private func configureCamera() {
            let camera = PerspectiveCamera()
            camera.position = [0, 0.08, 2.55]
            camera.look(at: [0, 0.02, 0], from: camera.position, relativeTo: nil)
            anchor.addChild(camera)
        }

        private func configureLighting() {
            let keyLight = DirectionalLight()
            keyLight.light.intensity = 2600
            keyLight.light.color = .init(red: 0.82, green: 0.92, blue: 1.0, alpha: 1.0)
            keyLight.orientation = simd_quatf(angle: -.pi / 4, axis: [1, 0, 0])
            anchor.addChild(keyLight)

            let fillLight = PointLight()
            fillLight.light.intensity = 1500
            fillLight.light.color = .init(red: 1.0, green: 0.78, blue: 0.45, alpha: 1.0)
            fillLight.position = [-0.55, 0.55, 0.65]
            anchor.addChild(fillLight)
        }

        private func installModel() {
            modelRoot = loadConfiguredModel() ?? makePlaceholderModel()
            modelRoot.name = "InteractiveModel"
            modelRoot.findEntity(named: "EffectBounds")?.isEnabled = false
            modelRoot.scale = SIMD3<Float>(repeating: 0.001)
            modelRoot.position = [0, -0.36, 0]
            modelRoot.generateCollisionShapes(recursive: true)
            anchor.addChild(modelRoot)
        }

        private func loadConfiguredModel() -> Entity? {
            guard
                let modelFileName = configuration.modelFileName,
                let url = Bundle.main.url(forResource: modelFileName, withExtension: nil, subdirectory: "Models")
            else {
                return nil
            }

            return try? Entity.load(contentsOf: url)
        }

        private func makePlaceholderModel() -> Entity {
            let material = SimpleMaterial(
                color: .init(red: 0.2, green: 0.72, blue: 0.95, alpha: 1.0),
                roughness: 0.28,
                isMetallic: true
            )
            let mesh = MeshResource.generateBox(size: 0.34, cornerRadius: 0.06)
            let box = ModelEntity(mesh: mesh, materials: [material])
            box.name = "PlaceholderModel"
            return box
        }

        private func installHalo() {
            var material = UnlitMaterial(color: .init(red: 0.1, green: 0.72, blue: 1.0, alpha: 0.09))
            material.blending = .transparent(opacity: 0.09)
            halo = ModelEntity(mesh: .generateSphere(radius: 0.5), materials: [material])
            halo.scale = [0.001, 0.001, 0.001]
            halo.position = [0, -0.36, 0]
            anchor.addChild(halo)
        }

        private func installFlashCore() {
            var material = UnlitMaterial(color: .init(red: 1.0, green: 0.96, blue: 0.55, alpha: 0.62))
            material.blending = .transparent(opacity: 0.62)
            flashCore = ModelEntity(mesh: .generateSphere(radius: 0.34), materials: [material])
            flashCore.scale = [0.001, 0.001, 0.001]
            flashCore.position = [0, 0, 0]
            flashCore.isEnabled = false
            anchor.addChild(flashCore)
        }

        private func installScanRing() {
            var material = UnlitMaterial(color: .init(red: 1.0, green: 0.88, blue: 0.28, alpha: 0.72))
            material.blending = .transparent(opacity: 0.72)
            scanRing = ModelEntity(mesh: .generateBox(size: [0.92, 0.012, 0.012]), materials: [material])
            scanRing.scale = [0.1, 1, 1]
            scanRing.position = [0, -0.34, 0]
            anchor.addChild(scanRing)
        }

        private func installSparkles() {
            sparkleGroup = Entity()
            anchor.addChild(sparkleGroup)

            for index in 0..<24 {
                var material = UnlitMaterial(color: .init(red: 0.72, green: 0.95, blue: 1.0, alpha: 0.9))
                material.blending = .transparent(opacity: 0.9)
                let piece = ModelEntity(mesh: .generateSphere(radius: 0.012), materials: [material])
                let angle = Float(index) / 24 * .pi * 2
                let radius: Float = index.isMultiple(of: 2) ? 0.44 : 0.62
                piece.position = [cos(angle) * radius, -0.24 + Float(index % 5) * 0.08, sin(angle) * radius]
                piece.scale = [0.001, 0.001, 0.001]
                sparkleGroup.addChild(piece)
                burstPieces.append(piece)
            }
        }

        private func startDisplayLink() {
            startTime = CACurrentMediaTime()
            lifecycleStartTime = startTime
            let link = CADisplayLink(target: self, selector: #selector(step))
            link.add(to: .main, forMode: .common)
            displayLink = link
        }

        @objc private func step() {
            let now = CACurrentMediaTime()
            let elapsed = Float(now - startTime)
            let disappearAge = disappearStart >= 0 ? Float(now - disappearStart) : -1
            if disappearAge >= disappearDuration + rebirthPause {
                lifecycleStartTime = now
                disappearStart = -10
                completionShakeStart = -10
                modelRoot.isEnabled = true
                halo.isEnabled = true
                flashCore.isEnabled = false
                scanRing.isEnabled = true
                sparkleGroup.isEnabled = true
            } else if disappearAge >= disappearDuration {
                modelRoot.isEnabled = false
                halo.isEnabled = false
                flashCore.isEnabled = false
                scanRing.isEnabled = false
                sparkleGroup.isEnabled = false
                return
            }

            let lifeElapsed = Float(now - lifecycleStartTime)
            let intro = easeOutBack(clamp(lifeElapsed / Float(configuration.growthDuration)))
            let introFade = easeOut(clamp(lifeElapsed / Float(configuration.growthDuration)))
            let floatOffset = sin(elapsed * configuration.floatSpeed) * configuration.floatAmplitude
            let shakeAge = completionShakeStart >= 0 ? Float(now - completionShakeStart) : -1
            if shakeAge >= completionShakeDuration {
                completionShakeStart = -10
                interactionUntil = now
                disappearStart = now
                NotificationCenter.default.post(name: .starBurstTriggered, object: nil)
                UIImpactFeedbackGenerator(style: .heavy).impactOccurred(intensity: 1.0)
            } else if shakeAge >= 0, now >= nextShakeHapticTime {
                let hapticProgress = clamp(shakeAge / completionShakeDuration)
                UIImpactFeedbackGenerator(style: .soft).impactOccurred(intensity: CGFloat(0.38 + hapticProgress * 0.42))
                nextShakeHapticTime = now + CFTimeInterval(0.36 - hapticProgress * 0.12)
            }

            let isCompletionShaking = shakeAge >= 0 && shakeAge < completionShakeDuration
            let shakeProgress = isCompletionShaking ? clamp(shakeAge / completionShakeDuration) : 0
            let charge = isCompletionShaking ? easeInOut(shakeProgress) : 0
            let preBurstKick = isCompletionShaking ? easeOut(clamp((shakeProgress - 0.86) / 0.14)) : 0
            let activeInteraction = isCompletionShaking ? (0.34 + charge * 0.5 + preBurstKick * 0.28) : max(0, Float(interactionUntil - now) / 0.72)
            let interactionAge = max(0, Float(now - interactionStart))
            let flashProgress = disappearAge >= 0 ? clamp(disappearAge / 0.16) : 0
            let collapseProgress = disappearAge >= 0 ? easeInOut(clamp((disappearAge - 0.12) / 0.38)) : 0
            let flash = disappearAge >= 0 ? sin(flashProgress * .pi) : 0
            let disappearHold = disappearAge >= 0 ? flash * 0.35 : 0
            let shakeEnvelope = isCompletionShaking ? activeInteraction : activeInteraction * activeInteraction
            let shakeOffset = isCompletionShaking
                ? sin(elapsed * 20) * shakeEnvelope * 0.04 + sin(elapsed * 46) * charge * 0.014 + sin(elapsed * 74) * preBurstKick * 0.034
                : sin(elapsed * 120) * shakeEnvelope * 0.09 + sin(elapsed * 61) * shakeEnvelope * 0.025
            let verticalShake = isCompletionShaking
                ? cos(elapsed * 16) * shakeEnvelope * 0.022 + cos(elapsed * 42) * charge * 0.008 + cos(elapsed * 68) * preBurstKick * 0.018
                : cos(elapsed * 86) * shakeEnvelope * 0.035
            let pop = isCompletionShaking
                ? 1 + sin(elapsed * 5.2) * (0.032 + charge * 0.036) + preBurstKick * sin(elapsed * 32) * 0.028 + sin(clamp(interactionAge / 0.3) * .pi) * 0.1
                : 1 + sin(clamp(interactionAge / 0.28) * .pi) * 0.2
            let chargeScale = isCompletionShaking ? 1 + charge * 0.36 + preBurstKick * 0.09 : 1
            let vanishScale = max(0.001, 1 - collapseProgress)
            let jellyScale = SIMD3<Float>(
                max(0.001, (1 + flash * 0.32) * vanishScale),
                max(0.001, (1 + flash * 0.32) * vanishScale),
                max(0.001, (1 + flash * 0.18) * vanishScale)
            )

            modelRoot.isEnabled = true
            halo.isEnabled = true
            sparkleGroup.isEnabled = true

            modelRoot.position.y = mix(-0.36, baseY, introFade) + floatOffset * introFade + verticalShake + collapseProgress * 0.12
            modelRoot.position.x = shakeOffset
            modelRoot.scale = configuration.modelScale * max(0.001, intro) * pop * chargeScale * jellyScale
            let faceSpin = simd_quatf(angle: elapsed * configuration.idleRotationSpeed, axis: [0, 1, 0])
            modelRoot.orientation = faceSpin * modelFacingCorrection

            halo.position = modelRoot.position
            halo.orientation = modelRoot.orientation
            sparkleGroup.orientation = modelFacingCorrection
            let haloPulse = 1.0 + sin(elapsed * 2.8) * 0.08 + activeInteraction * 0.95 + flash * 3.2
            halo.scale = SIMD3<Float>(repeating: max(0.001, introFade) * haloPulse * max(0.001, 1 - collapseProgress * 0.45))
            flashCore.position = modelRoot.position
            flashCore.orientation = modelRoot.orientation
            flashCore.scale = SIMD3<Float>(repeating: max(0.001, flash * 1.45))
            flashCore.isEnabled = flash > 0.02

            let ringIntro = clamp(lifeElapsed / 1.05)
            let ringBurst = activeInteraction > 0 ? easeOut(clamp(interactionAge / 0.48)) : disappearHold
            scanRing.position.y = mix(-0.34, 0.28, ringIntro) + floatOffset * 0.3
            let ringScale = 0.18 + ringIntro * 1.15 + ringBurst * 0.75
            scanRing.scale = [ringScale, 1, 1]
            scanRing.orientation = faceSpin * modelFacingCorrection
            scanRing.isEnabled = false

            updateSparkles(
                elapsed: elapsed,
                intro: introFade * max(0.001, 1 - collapseProgress),
                interactionAge: interactionAge,
                activeInteraction: max(activeInteraction, disappearHold),
                flash: flash
            )
        }

        private func updateSparkles(elapsed: Float, intro: Float, interactionAge: Float, activeInteraction: Float, flash: Float) {
            for (index, piece) in burstPieces.enumerated() {
                let angle = Float(index) / Float(max(1, burstPieces.count)) * .pi * 2
                let introRadius = 0.12 + intro * (index.isMultiple(of: 2) ? 0.42 : 0.58)
                let burst = activeInteraction > 0 ? easeOut(clamp(interactionAge / 0.48)) : 0
                let burstRadius = introRadius + burst * 0.55 + flash * 0.7
                let orbit = angle + elapsed * (0.45 + Float(index % 4) * 0.07)
                piece.position = [
                    cos(orbit) * burstRadius,
                    mix(-0.28, 0.24, intro) + sin(elapsed * 1.8 + Float(index)) * 0.055 + burst * 0.1,
                    sin(orbit) * burstRadius
                ]
                let base = intro * (0.45 + 0.3 * sin(elapsed * 3 + Float(index)))
                let burstScale = sin(clamp(interactionAge / 0.34) * .pi) * activeInteraction + flash * 1.8
                piece.scale = SIMD3<Float>(repeating: max(0.001, 0.55 + base + burstScale * 1.2))
                piece.isEnabled = intro > 0.03 || activeInteraction > 0
            }
        }

        private func isNearStageCenter(_ location: CGPoint, in view: UIView) -> Bool {
            let center = CGPoint(x: view.bounds.midX, y: view.bounds.midY)
            let dx = location.x - center.x
            let dy = location.y - center.y
            return sqrt(dx * dx + dy * dy) < min(view.bounds.width, view.bounds.height) * 0.32
        }

        private func clamp(_ value: Float) -> Float {
            min(1, max(0, value))
        }

        private func easeOut(_ value: Float) -> Float {
            1 - pow(1 - value, 3)
        }

        private func easeInOut(_ value: Float) -> Float {
            value < 0.5 ? 2 * value * value : 1 - pow(-2 * value + 2, 2) / 2
        }

        private func easeOutBack(_ value: Float) -> Float {
            let c1: Float = 1.70158
            let c3 = c1 + 1
            return 1 + c3 * pow(value - 1, 3) + c1 * pow(value - 1, 2)
        }

        private func mix(_ start: Float, _ end: Float, _ progress: Float) -> Float {
            start + (end - start) * progress
        }
    }
}
