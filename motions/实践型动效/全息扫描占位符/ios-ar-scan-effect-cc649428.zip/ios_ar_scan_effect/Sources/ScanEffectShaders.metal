#include <metal_stdlib>
#include <RealityKit/RealityKit.h>

using namespace metal;

static float bandAlpha(float normalizedY, float center, float height) {
    float distanceToBand = abs(normalizedY - center);
    float core = 1.0 - smoothstep(height * 0.42, height, distanceToBand);
    return clamp(core, 0.0, 1.0);
}

[[visible]]
void scanBodySurface(realitykit::surface_parameters params) {
    float4 scan = params.uniforms().custom_parameter();
    float bodyOpacity = scan.x;
    float rimStrength = scan.y;

    float3 localPosition = params.geometry().model_position();
    float3 normal = normalize(params.geometry().normal());
    float3 viewDirection = normalize(params.geometry().view_direction());
    float fresnelBase = 1.0 - saturate(abs(dot(normal, viewDirection)));
    float fresnel = pow(fresnelBase, 1.28);
    float edgeCore = pow(fresnelBase, 4.5);
    float scanLines = pow(0.5 + 0.5 * sin(localPosition.y * 130.0), 24.0);
    float centerMilk = pow(saturate(abs(normal.z)), 0.55) * 0.075 + 0.018;
    float verticalHighlight = pow(1.0 - saturate(abs(localPosition.x) * 6.0), 12.0) * 0.42;

    half3 bodyColor = half3(0.08h, 1.0h, 0.74h);
    half3 milkColor = half3(0.62h, 0.96h, 0.78h);
    half3 rimColor = half3(0.92h, 1.0h, 0.92h);
    float rim = clamp(fresnel * rimStrength, 0.0, 1.0);
    half3 innerColor = mix(bodyColor, milkColor, half(centerMilk));
    half3 color = mix(innerColor, rimColor, half(clamp(rim * 0.62, 0.0, 0.72)));

    params.surface().set_base_color(color);
    params.surface().set_emissive_color(bodyColor * 0.42h + rimColor * half(fresnel * 1.55 + edgeCore * 1.2 + scanLines * 0.04 + verticalHighlight * 0.24));
    params.surface().set_opacity(half(clamp(bodyOpacity + fresnel * 0.11 + centerMilk * 0.02 + verticalHighlight * 0.04, 0.18, 0.54)));
    params.surface().set_roughness(1.0h);
    params.surface().set_metallic(0.0h);
}

[[visible]]
void scanGridSurface(realitykit::surface_parameters params) {
    float4 scan = params.uniforms().custom_parameter();
    float center = scan.x;
    float height = max(scan.y, 0.01);
    float intensity = scan.z;

    float3 localPosition = params.geometry().model_position();
    float normalizedY = clamp((localPosition.y + 25.0) / 50.0, 0.0, 1.0);
    float reveal = bandAlpha(normalizedY, center, height);

    half3 lineColor = half3(0.18h, 1.0h, 0.78h);
    params.surface().set_base_color(lineColor);
    params.surface().set_emissive_color(lineColor * half((intensity + 0.85) * reveal));
    params.surface().set_opacity(half(reveal * 0.58));
    params.surface().set_roughness(1.0h);
    params.surface().set_metallic(0.0h);
}
