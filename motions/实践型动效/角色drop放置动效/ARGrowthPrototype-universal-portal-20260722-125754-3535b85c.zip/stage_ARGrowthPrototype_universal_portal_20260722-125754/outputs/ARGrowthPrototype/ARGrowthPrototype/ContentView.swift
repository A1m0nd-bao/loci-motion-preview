import SwiftUI

struct ContentView: View {
    @State private var replayToken = UUID()

    var body: some View {
        ZStack(alignment: .bottom) {
            GrowthSceneView(replayToken: replayToken)
                .ignoresSafeArea()

            HStack(spacing: 12) {
                Button {
                    replayToken = UUID()
                } label: {
                    Image(systemName: "gobackward")
                        .font(.system(size: 18, weight: .semibold))
                        .frame(width: 48, height: 48)
                }
                .buttonStyle(.borderedProminent)
                .tint(.white.opacity(0.22))
                .foregroundStyle(.white)

                VStack(alignment: .leading, spacing: 4) {
                    Text("Growth placement prototype")
                        .font(.headline)
                    Text("Tap the surface to replay on device AR, or use the preview plane in Simulator.")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.72))
                }
                .lineLimit(2)

                Spacer(minLength: 0)
            }
            .padding(14)
            .background(.ultraThinMaterial)
            .clipShape(RoundedRectangle(cornerRadius: 8))
            .padding(.horizontal, 16)
            .padding(.bottom, 18)
        }
        .preferredColorScheme(.dark)
    }
}
