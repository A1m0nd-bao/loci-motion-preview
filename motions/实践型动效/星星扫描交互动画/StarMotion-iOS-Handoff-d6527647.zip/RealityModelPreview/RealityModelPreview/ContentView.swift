import SwiftUI
import UIKit

extension Notification.Name {
    static let starBurstTriggered = Notification.Name("starBurstTriggered")
    static let starStageTapped = Notification.Name("starStageTapped")
}

struct ContentView: View {
    @State private var burstTrigger = 0

    var body: some View {
        ZStack(alignment: .bottom) {
            ModelStageView(configuration: .demo)
                .ignoresSafeArea()

            Color.clear
                .contentShape(Rectangle())
                .onTapGesture {
                    NotificationCenter.default.post(name: .starStageTapped, object: nil)
                }
                .ignoresSafeArea()

            ImageSequenceOverlay(trigger: burstTrigger)
                .allowsHitTesting(false)

            VStack(spacing: 8) {
                Text("Reality Model Preview")
                    .font(.headline)
                Text("Tap the model to trigger haptic shake and completion animation.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
            .padding(16)
            .frame(maxWidth: 360)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 8))
            .padding(.bottom, 28)
        }
        .onReceive(NotificationCenter.default.publisher(for: .starBurstTriggered)) { _ in
            burstTrigger += 1
        }
    }
}

private struct ImageSequenceOverlay: View {
    let trigger: Int

    private let frameCount = 40
    private let timer = Timer.publish(every: 1.0 / 30.0, on: .main, in: .common).autoconnect()

    @State private var frameIndex = 0
    @State private var isPlaying = false

    var body: some View {
        ZStack {
            if isPlaying, let image = currentFrameImage {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .scaleEffect(effectScale)
                    .blendMode(.screen)
                    .opacity(frameOpacity)
            }
        }
        .clipped()
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .onChange(of: trigger) { _, newValue in
            guard newValue > 0 else { return }
            play()
        }
        .onReceive(timer) { _ in
            guard isPlaying else { return }
            if frameIndex < frameCount - 1 {
                frameIndex += 1
            } else {
                isPlaying = false
            }
        }
    }

    private func play() {
        frameIndex = 0
        isPlaying = true
    }

    private var currentFrameImage: UIImage? {
        let fileName = String(format: "explosion_%04d", frameIndex)
        guard let url = Bundle.main.url(forResource: fileName, withExtension: "png", subdirectory: "Effects/Explosion07") else {
            return nil
        }
        return UIImage(contentsOfFile: url.path)
    }

    private var frameOpacity: Double {
        let progress = Double(frameIndex) / Double(max(1, frameCount - 1))
        return min(1, max(0, 1 - max(0, progress - 0.82) / 0.18))
    }

    private var effectScale: Double {
        let progress = Double(frameIndex) / Double(max(1, frameCount - 1))
        return 1.18 + min(1, progress / 0.4) * 0.08
    }
}
