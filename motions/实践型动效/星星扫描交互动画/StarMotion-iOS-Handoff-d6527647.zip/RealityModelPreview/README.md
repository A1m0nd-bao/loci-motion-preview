# RealityModelPreview

This is a small iOS RealityKit preview app for testing one 3D interaction:

1. The model grows into the scene.
2. It idles with slow rotation and subtle floating motion.
3. One tap triggers a 3-second shake sequence with haptic pulses.
4. After the shake sequence, a PNG image sequence effect plays while the model disappears and then grows back in.

## Add Your Model

Put your model in:

```text
RealityModelPreview/Models/
```

Recommended iOS format:

- `.usdz` is preferred
- `.reality` also works
- `.glb`, `.gltf`, `.fbx`, `.obj` should be converted to `.usdz`

This preview is already set to load:

```text
RealityModelPreview/Models/model_with_effect_bounds.usdz
```

This USDZ includes a transparent bounds cube at `/root/EffectBounds`. The bounds node is meant for AR handoff: use it as the shared size reference between the star and the explosion/Lottie effect.

To swap in another model later, edit `RealityModelPreview/ModelStageView.swift`:

```swift
static let demo = ModelStageConfiguration(
    modelFileName: "YourModel.usdz",
    modelScale: SIMD3<Float>(repeating: 1.0),
    growthDuration: 1.15,
    idleRotationSpeed: 0.45,
    floatAmplitude: 0.035,
    floatSpeed: 1.4
)
```

## Tune Motion

- `growthDuration`: how long the model takes to grow in
- `idleRotationSpeed`: normal rotation speed
- `floatAmplitude`: up/down floating distance
- `floatSpeed`: floating rhythm
- `completionShakeDuration` in `ModelStageView.swift`: shake length after tap
- `disappearDuration`: disappear animation length
- `ImageSequenceOverlay` in `ContentView.swift`: temporary PNG sequence effect playback

## Temporary Image Sequence Effect

The current disappear effect uses PNG frames in:

```text
RealityModelPreview/Effects/Explosion07/
```

These frames are a temporary stand-in for the future Lottie file.

## Open In Xcode

Open:

```text
RealityModelPreview.xcodeproj
```

Choose an iPhone simulator or a connected iPhone, then press Run.

If Xcode says the iOS platform is missing, install it from:

```text
Xcode > Settings > Components
```
