import Foundation
import Metal
import RealityKit
import simd

enum ScanMaterials {
    static func makeBodyMaterial(config: ScanEffectConfig) throws -> CustomMaterial {
        var base = PhysicallyBasedMaterial()
        base.baseColor = .init(tint: .init(red: CGFloat(config.bodyColor.x),
                                           green: CGFloat(config.bodyColor.y),
                                           blue: CGFloat(config.bodyColor.z),
                                           alpha: CGFloat(config.bodyOpacity)))
        base.roughness = .init(floatLiteral: 1.0)
        base.metallic = .init(floatLiteral: 0.0)
        base.blending = .transparent(opacity: .init(floatLiteral: config.bodyOpacity))
        let shader = CustomMaterial.SurfaceShader(named: "scanBodySurface", in: try makeLibrary())
        var material = try CustomMaterial(from: base, surfaceShader: shader)
        material.custom.value = SIMD4<Float>(config.bodyOpacity, config.rimStrength, 0.0, 0.0)
        return material
    }

    static func makeFaintGridMaterial(config: ScanEffectConfig) -> Material {
        var material = UnlitMaterial(color: .init(red: CGFloat(config.gridColor.x),
                                                  green: CGFloat(config.gridColor.y),
                                                  blue: CGFloat(config.gridColor.z),
                                                  alpha: 0.18))
        material.blending = .transparent(opacity: 0.18)
        return material
    }

    static func makeGridMaterial(config: ScanEffectConfig) throws -> CustomMaterial {
        var base = UnlitMaterial(color: .init(red: CGFloat(config.gridColor.x),
                                              green: CGFloat(config.gridColor.y),
                                              blue: CGFloat(config.gridColor.z),
                                              alpha: 1.0))
        base.blending = .transparent(opacity: 1.0)
        let shader = CustomMaterial.SurfaceShader(named: "scanGridSurface", in: try makeLibrary())
        var material = try CustomMaterial(from: base, surfaceShader: shader)
        material.custom.value = SIMD4<Float>(0.0, config.scanHeight, config.gridIntensity, 0.0)
        return material
    }

    private static func makeLibrary() throws -> MTLLibrary {
        guard let device = MTLCreateSystemDefaultDevice(),
              let library = device.makeDefaultLibrary() else {
            throw ScanMaterialError.metalLibraryUnavailable
        }
        return library
    }
}

enum ScanMaterialError: Error {
    case metalLibraryUnavailable
}
