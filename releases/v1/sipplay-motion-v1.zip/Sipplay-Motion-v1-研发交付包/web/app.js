import { motionMotions } from "./motion/catalog.js?v=20261028-image-dark1";
import { webMotions } from "./web-components/catalog.js?v=20261028-image-dark1";
import { createWebController, copyExample, downloadExample, setupWebDetail, getWebValues, syncWebBackgrounds } from "./web-components/integration.js?v=20261028-image-dark1";

if (import.meta.env?.DEV) document.querySelector("#motionStudioLocal").hidden = false;

const isInteractiveKind = kind => kind === "web" || kind === "motion";

const gallery = document.querySelector("#gallery");
const quickRail = document.querySelector("#quickRail");
const formatNav = document.querySelector("#formatNav");
const homeView = document.querySelector("#homeView");
const homeModules = document.querySelector("#homeModules");
const homePrimaryCta = document.querySelector("#homePrimaryCta");
const homeSecondaryCta = document.querySelector("#homeSecondaryCta");
const homeTotal = document.querySelector("#homeTotal");
const homeFormats = document.querySelector("#homeFormats");
const homeCategories = document.querySelector("#homeCategories");
const homePanelTotal = document.querySelector("#homePanelTotal");
const homeBreakdown = document.querySelector("#homeBreakdown");
const quickSection = document.querySelector("#quickSection");
const libraryView = document.querySelector("#libraryView");
const homeTrigger = document.querySelector("#homeTrigger");
const sidebar = document.querySelector(".sidebar");
const empty = document.querySelector("#empty");
const count = document.querySelector("#count");
const search = document.querySelector("#search");
const kindSelect = document.querySelector("#kind");
const category = document.querySelector("#category");
const speed = document.querySelector("#speed");
const speedLabel = document.querySelector("#speedLabel");
const previewBg = document.querySelector("#previewBg");
const previewBgLabel = document.querySelector("#previewBgLabel");
const autoplay = document.querySelector("#autoplay");
const loop = document.querySelector("#loop");
const refresh = document.querySelector("#refresh");
const videoSpotlight = document.querySelector("#videoSpotlight");
const videoSpotlightStage = document.querySelector("#videoSpotlightStage");
const videoSpotlightPlayer = document.querySelector("#videoSpotlightPlayer");
const videoSpotlightTitle = document.querySelector("#videoSpotlightTitle");
const videoSpotlightMeta = document.querySelector("#videoSpotlightMeta");
const fileInput = document.querySelector("#fileInput");
const dropzone = document.querySelector("#dropzone");
const template = document.querySelector("#motionCard");
const quickTemplate = document.querySelector("#quickCard");
const moduleTemplate = document.querySelector("#moduleCard");
const detailDialog = document.querySelector("#detailDialog");
const detailTitle = document.querySelector("#detailTitle");
const detailPath = document.querySelector("#detailPath");
const detailHost = document.querySelector("#detailPlayer");
const detailClose = document.querySelector("#detailClose");
const detailPlay = document.querySelector("#detailPlay");
const detailPause = document.querySelector("#detailPause");
const detailSpeed = document.querySelector("#detailSpeed");
const detailSpeedLabel = document.querySelector("#detailSpeedLabel");
const detailLoop = document.querySelector("#detailLoop");
const detailPreviewBg = document.querySelector("#detailPreviewBg");
const detailPreviewBgLabel = document.querySelector("#detailPreviewBgLabel");
const detailResolution = document.querySelector("#detailResolution");
const detailTags = document.querySelector("#detailTags");
const detailTimeline = document.querySelector("#detailTimeline");
const detailCurrentFrame = document.querySelector("#detailCurrentFrame");
const detailTotalFrames = document.querySelector("#detailTotalFrames");
const detailCurrentTime = document.querySelector("#detailCurrentTime");
const detailTotalDuration = document.querySelector("#detailTotalDuration");
const detailCopy = document.querySelector("#detailCopy");
const detailOpen = document.querySelector("#detailOpen");
const detailDownload = document.querySelector("#detailDownload");

let motions = [];
let visibleMotions = [];
let activeMotion = null;
let activeMotionInfo = null;
let detailController = null;
let timelineRaf = 0;
let currentView = "home";
let activeKind = "all";
let homeOpeningTimer = 0;
let homeVisualWakeTimer = 0;
let manifestSignature = "";

const motionInfoCache = new Map();
const previewBackgroundKey = "motion-preview-bg";
const defaultPreviewBackground = "#0a0c10";
const previewPosterFrameRatio = 0.35;
const kindLabels = {
  all: "全部格式",
  lottie: "Lottie",
  video: "视频动效",
  gif: "GIF",
  rive: "Rive",
  practice: "实践型动效",
  web: "Web 组件",
  motion: "Motion",
};
const live2dModule = {
  label: "Live2D",
  description: "角色模型与交互预览",
  href: "https://a1m0nd-bao.github.io/loci-live2d-preview/",
};
const previewControllers = new WeakMap();
const lazyHostObserver =
  "IntersectionObserver" in window
    ? new IntersectionObserver(handleHostVisibility, {
        root: null,
        rootMargin: "360px",
        threshold: 0.01,
      })
    : null;

if (window.matchMedia("(max-width: 820px)").matches) {
  sidebar.removeAttribute("open");
}

applyPreviewBackground(localStorage.getItem(previewBackgroundKey) || defaultPreviewBackground, {
  persist: false,
});
startHomeOpening({ returning: false });

async function loadManifest() {
  try {
    const response = await fetch(`./manifest.json?time=${Date.now()}`);
    if (!response.ok) throw new Error("manifest not found");
    const data = await response.json();
    const remoteLabels = data.kindLabels && typeof data.kindLabels === "object" ? data.kindLabels : {};
    Object.assign(kindLabels, remoteLabels);
    const items = Array.isArray(data.items) ? data.items : [];
    const signature = JSON.stringify([items, remoteLabels]);
    if (signature === manifestSignature) return;
    manifestSignature = signature;
    motions = items.map(normalizeMotion);
  } catch {
    if (motions.length) return;
    motions = [];
  }

  // Kept separate from the generated asset manifest so sync jobs cannot prune the catalog.
  motions.push(...webMotions.map(normalizeMotion), ...motionMotions.map(normalizeMotion));

  populateKinds();
  populateCategories();
  render();
}

function normalizeMotion(item) {
  const kind = normalizeKind(item.kind || item.format || item.kindLabel || item.file);
  return {
    ...item,
    kind,
    kindLabel: kindLabels[kind] || item.kindLabel || kind,
    category: item.category || "未分类",
    tags: Array.isArray(item.tags) ? item.tags : [],
    fileName: item.fileName || filenameToName(item.file),
    firstSeenAt: item.firstSeenAt || "",
  };
}

function populateKinds() {
  const selected = kindSelect.value || "all";
  const counts = countBy(motions, (item) => item.kind || "practice");
  const kinds = getOrderedKinds(counts);

  kindSelect.innerHTML = '<option value="all">全部格式</option>';
  for (const kind of kinds) {
    const option = document.createElement("option");
    option.value = kind;
    option.textContent = `${labelForKind(kind)} (${counts[kind]})`;
    kindSelect.append(option);
  }
  kindSelect.value = kinds.includes(selected) ? selected : "all";

  formatNav.replaceChildren();
  formatNav.append(createFormatButton("all", "全部格式", motions.length, "总览所有动效资产"));
  for (const kind of kinds) {
    formatNav.append(createFormatButton(kind, labelForKind(kind), counts[kind], formatDescription(kind)));
  }
  formatNav.append(createExternalFormatLink(live2dModule));

  renderHomeModules(kinds, counts);
  renderHomeIndex(kinds, counts);
}

function createFormatButton(kind, label, amount, description) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = `format-button${kindSelect.value === kind ? " active" : ""}`;
  button.dataset.kind = kind;
  button.innerHTML = `<strong></strong><span class="format-count"></span><span></span>`;
  button.querySelector("strong").textContent = label;
  button.querySelector(".format-count").textContent = String(amount);
  button.querySelector("span:last-child").textContent = description;
  button.addEventListener("click", () => {
    enterModule(kind);
  });
  return button;
}

function createExternalFormatLink({ label, description, href }) {
  const link = document.createElement("a");
  link.className = "format-button format-button-external";
  link.href = href;
  link.target = "_blank";
  link.rel = "noreferrer noopener";
  link.innerHTML = `<strong></strong><span class="format-count">↗</span><span></span>`;
  link.querySelector("strong").textContent = label;
  link.querySelector("span:last-child").textContent = description;
  link.setAttribute("aria-label", `打开 ${label} 预览站`);
  return link;
}

function renderHomeModules(kinds, counts) {
  homeModules.replaceChildren();
  for (const kind of kinds) {
    homeModules.append(createModuleCard(kind, counts[kind] || 0));
  }

  for (const kind of ["video", "gif", "practice"]) {
    if (counts[kind]) continue;
    homeModules.append(createModuleCard(kind, 0));
  }

  homeModules.append(createExternalModuleCard(live2dModule));
}

function renderHomeIndex(kinds, counts) {
  const categories = new Set(motions.map((item) => item.category || "未分类"));
  homeTotal.textContent = String(motions.length);
  homeFormats.textContent = String(kinds.length);
  homeCategories.textContent = String(categories.size);
  homePanelTotal.textContent = String(motions.length);

  homeBreakdown.replaceChildren();
  const total = Math.max(1, motions.length);
  const rows = kinds.length ? kinds : ["lottie"];
  for (const kind of rows.slice(0, 5)) {
    const amount = counts[kind] || 0;
    const row = document.createElement("div");
    row.className = "home-breakdown-row";
    row.innerHTML = `
      <span><strong></strong><em></em></span>
      <div class="home-breakdown-bar"><i></i></div>
    `;
    row.querySelector("strong").textContent = labelForKind(kind);
    row.querySelector("em").textContent = String(amount);
    row.querySelector("i").style.width = `${Math.max(4, (amount / total) * 100)}%`;
    homeBreakdown.append(row);
  }
}

function createModuleCard(kind, amount) {
  const node = moduleTemplate.content.firstElementChild.cloneNode(true);
  node.dataset.kind = kind;
  node.querySelector(".module-icon").textContent = moduleIcon(kind);
  node.querySelector("strong").textContent = labelForKind(kind);
  node.querySelector(".module-meta").textContent = `${amount} 个资产 / ${formatDescription(kind)}`;
  node.addEventListener("click", () => enterModule(kind));
  return node;
}

function createExternalModuleCard({ label, description, href }) {
  const link = document.createElement("a");
  link.className = "module-card module-card-external";
  link.href = href;
  link.target = "_blank";
  link.rel = "noreferrer noopener";
  link.innerHTML = `
    <span class="module-icon">2D</span>
    <strong></strong>
    <span class="module-meta"></span>
    <span class="module-link-label">打开预览站 ↗</span>
  `;
  link.querySelector("strong").textContent = label;
  link.querySelector(".module-meta").textContent = description;
  link.setAttribute("aria-label", `打开 ${label} 预览站`);
  return link;
}

function enterModule(kind) {
  finishHomeOpening();
  window.dispatchEvent(new CustomEvent("motion-home-visual-sleep"));
  currentView = "library";
  if (activeKind !== kind) {
    search.value = "";
    category.value = "all";
  }
  activeKind = kind;
  kindSelect.value = kind;
  history.replaceState(null, "", `${location.pathname}${location.search}${isInteractiveKind(kind) ? `#${kind}` : ""}`);
  populateCategories();
  render();
}

function showHome() {
  history.replaceState(null, "", `${location.pathname}${location.search}`);
  currentView = "home";
  activeKind = "all";
  kindSelect.value = "all";
  populateCategories();
  startHomeOpening({ returning: true });
  render();
}

function startHomeOpening({ returning = false } = {}) {
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  window.clearTimeout(homeOpeningTimer);
  window.clearTimeout(homeVisualWakeTimer);

  if (reduceMotion) {
    finishHomeOpening();
    return;
  }

  document.body.classList.add("home-opening");
  document.body.classList.toggle("is-returning-home", returning);
  scheduleHomeVisualWake(returning);
  homeOpeningTimer = window.setTimeout(finishHomeOpening, returning ? 820 : 4650);
}

function finishHomeOpening() {
  window.clearTimeout(homeOpeningTimer);
  window.clearTimeout(homeVisualWakeTimer);
  document.body.classList.remove("home-opening", "is-returning-home");
}

function scheduleHomeVisualWake(returning) {
  homeVisualWakeTimer = window.setTimeout(
    () => window.dispatchEvent(new CustomEvent("motion-home-visual-wake")),
    returning ? 120 : 2750,
  );
}

function populateCategories() {
  const selected = category.value || "all";
  const selectedKind = kindSelect.value;
  const source = selectedKind === "all" ? motions : motions.filter((item) => item.kind === selectedKind);
  const categories = [...new Set(source.map((item) => item.category || "未分类"))].sort((a, b) =>
    a.localeCompare(b, "zh-Hans-CN"),
  );
  category.innerHTML = '<option value="all">全部分类</option>';

  for (const item of categories) {
    const option = document.createElement("option");
    option.value = item;
    option.textContent = item;
    category.append(option);
  }

  category.value = categories.includes(selected) ? selected : "all";
}

function render() {
  const isHome = currentView === "home";
  const query = search.value.trim().toLowerCase();
  const selectedKind = kindSelect.value;
  const selectedCategory = category.value;

  document.body.classList.toggle("is-home-view", isHome);
  visibleMotions = isHome ? motions : motions.filter((item) => {
    const haystack = [item.name, item.file, item.kindLabel, item.category, item.interactionType, ...(item.tags || [])]
      .join(" ")
      .toLowerCase();
    const matchesSearch = !query || haystack.includes(query);
    const matchesKind = selectedKind === "all" || item.kind === selectedKind;
    const matchesCategory = selectedCategory === "all" || item.category === selectedCategory;
    return matchesSearch && matchesKind && matchesCategory;
  });

  // Embedded component runtimes must be torn down when filters replace their cards.
  for (const host of gallery.querySelectorAll('[data-kind="web"]')) previewControllers.get(host)?.destroy?.();
  lazyHostObserver?.disconnect();
  gallery.replaceChildren();
  quickRail.replaceChildren();
  previewControllers.get(videoSpotlightPlayer)?.destroy?.();
  previewControllers.delete(videoSpotlightPlayer);
  videoSpotlight.hidden = isHome || selectedKind !== "video" || visibleMotions.length === 0;
  videoSpotlightPlayer.replaceChildren();
  count.textContent = String(visibleMotions.length);
  empty.hidden = visibleMotions.length > 0;
  homeView.hidden = !isHome;
  quickSection.hidden = isHome || isInteractiveKind(selectedKind);
  document.querySelector("#webLibraryIntro").hidden = isHome || selectedKind !== "web";
  document.querySelector("#motionLibraryIntro").hidden = isHome || selectedKind !== "motion";
  document.querySelectorAll("[data-library-media-only]").forEach((el) => { el.hidden = isInteractiveKind(selectedKind); });
  libraryView.hidden = isHome;

  if (isHome) {
    updateFormatActiveState();
    return;
  }

  if (selectedKind === "video" && visibleMotions.length) {
    renderVideoSpotlight(visibleMotions[0]);
  }

  const quickMotions = [...visibleMotions]
    .sort((a, b) => getUpdatedTime(b) - getUpdatedTime(a))
    .slice(0, 8);

  renderGalleryCards(visibleMotions, selectedKind);

  for (const motion of quickMotions.filter((item) => !isInteractiveKind(item.kind))) {
    quickRail.append(createQuickCard(motion));
  }

  updateFormatActiveState();
  syncPreviewHosts();
}

function renderVideoSpotlight(motion) {
  videoSpotlightTitle.textContent = motion.fileName || motion.name || filenameToName(motion.file);
  videoSpotlightMeta.textContent = [motion.category, motion.interactionType, "MOV / MP4 / HEVC / Alpha"]
    .filter(Boolean)
    .join("  /  ");
  setupPreviewHost(videoSpotlightPlayer, motion);
  videoSpotlightStage.onclick = () => openDetail(motion);
}

function getUpdatedTime(motion) {
  const time = Date.parse(motion.updatedAt || motion.createdAt || "");
  return Number.isFinite(time) ? time : 0;
}

function renderGalleryCards(items, selectedKind) {
  if (selectedKind === "web") {
    if (items.length) {
      const heading = document.createElement("h2");
      heading.className = "web-source-heading";
      heading.textContent = "sipplay";
      gallery.append(heading);
    }
    for (const motion of items) gallery.append(createCard(motion));
    return;
  }

  if (selectedKind !== "lottie") {
    for (const motion of items) gallery.append(createCard(motion));
    return;
  }

  const recentItems = [];
  const historicalItems = [];
  for (const motion of items) {
    if (isHistoricalLottie(motion)) historicalItems.push(motion);
    else recentItems.push(motion);
  }

  for (const motion of recentItems) gallery.append(createCard(motion));

  if (!historicalItems.length) return;
  gallery.append(createHistoryDivider(historicalItems.length));
  for (const motion of historicalItems) gallery.append(createCard(motion));
}

function isHistoricalLottie(motion) {
  if (motion.kind !== "lottie") return false;
  const time = Date.parse(motion.firstSeenAt || motion.createdAt || motion.updatedAt || "");
  return Number.isFinite(time) && time < Date.parse("2026-07-01T00:00:00+08:00");
}

function createHistoryDivider(amount) {
  const divider = document.createElement("div");
  divider.className = "history-divider";
  divider.innerHTML = `
    <strong>历史上传动效</strong>
    <em>${amount} 个 / 7 月前上传</em>
  `;
  return divider;
}

function createQuickCard(motion) {
  const node = quickTemplate.content.firstElementChild.cloneNode(true);
  const host = node.querySelector(".media-host");
  const label = node.querySelector("span");

  setupPreviewHost(host, motion);
  label.textContent = getMotionTitle(motion);
  node.title = `${label.textContent} - ${motion.kindLabel} - ${motion.category || "未分类"}`;
  node.addEventListener("click", () => openDetail(motion));

  return node;
}

function createCard(motion) {
  const node = template.content.firstElementChild.cloneNode(true);
  const host = node.querySelector(".media-host");
  const title = node.querySelector("h2");
  const path = node.querySelector(".path");
  const resolution = node.querySelector(".resolution");
  const badge = node.querySelector(".badge");
  const tags = node.querySelector(".tags");
  const openLink = node.querySelector("a");
  const downloadLink = node.querySelector(".download-link");

  setupPreviewHost(host, motion);

  title.textContent = getMotionTitle(motion);
  path.textContent = motion.file;
  path.title = motion.file;
  resolution.textContent = "规格 --";
  badge.textContent = motion.kindLabel || labelForKind(motion.kind);
  openLink.href = motion.file;
  downloadLink.href = motion.file;
  downloadLink.download = getDownloadName(motion);

  if (isInteractiveKind(motion.kind)) {
    node.classList.add("web-motion-card");
    path.textContent = motion.id;
    resolution.textContent = motion.description;
    resolution.dataset.loaded = "true";
    node.querySelector('[data-action="detail"]').textContent = "体验 / 代码";
    node.querySelector('[data-action="copy"]').textContent = "复制 HTML";
    openLink.textContent = "独立体验";
    downloadLink.textContent = "下载 HTML";
    downloadLink.addEventListener("click", (event) => {
      event.preventDefault();
      downloadExample(motion);
    });
  }

  const tagValues = [motion.category, motion.interactionType, ...(motion.tags || [])].filter(Boolean);
  for (const tag of tagValues) {
    const tagNode = document.createElement("span");
    tagNode.textContent = tag;
    tags.append(tagNode);
  }

  node.addEventListener("click", async (event) => {
    const action = event.target.dataset.action;
    if (!action && event.target.closest("a")) return;
    if (!action) {
      openDetail(motion);
      return;
    }

    const controller = ensurePreviewController(host, motion);
    if (action === "play") controller.play?.();
    if (action === "pause") controller.pause?.();
    if (action === "detail") openDetail(motion);
    if (action === "copy") {
      if (isInteractiveKind(motion.kind)) {
        await copyExample(event.target, motion);
        return;
      }
      await navigator.clipboard.writeText(motion.file);
      event.target.textContent = "已复制";
      window.setTimeout(() => {
        event.target.textContent = "复制路径";
      }, 1100);
    }
  });

  return node;
}

function setupPreviewHost(host, motion) {
  host.classList.toggle("is-lottie", motion.kind === "lottie");
  host.dataset.loaded = "false";
  host.dataset.visible = "false";
  host.dataset.previewActive = "false";
  host.dataset.kind = motion.kind;
  host.dataset.src = motion.file;
  applyMediaSizing(host, motion);
  bindPreviewFocusPlayback(host, motion);

  if (lazyHostObserver) {
    lazyHostObserver.observe(host);
    return;
  }

  host.dataset.visible = "true";
  ensurePreviewController(host, motion);
  syncPreviewHost(host);
  updateVisibleHostInfo(host, motion);
}

function handleHostVisibility(entries) {
  for (const entry of entries) {
    const host = entry.target;
    const motion = motions.find((item) => item.file === host.dataset.src);
    host.dataset.visible = entry.isIntersecting ? "true" : "false";

    if (entry.isIntersecting && motion) {
      ensurePreviewController(host, motion);
      syncPreviewHost(host);
      updateVisibleHostInfo(host, motion);
    } else if (host.dataset.kind === "web") {
      previewControllers.get(host)?.destroy?.();
      previewControllers.delete(host);
      host.replaceChildren();
      host.dataset.loaded = "false";
    } else {
      previewControllers.get(host)?.pause?.();
    }
  }
}

function ensurePreviewController(host, motion) {
  if (previewControllers.has(host)) return previewControllers.get(host);
  const controller = createMediaController(host, motion, { detail: false });
  previewControllers.set(host, controller);
  host.dataset.loaded = "true";
  controller.ready?.().then(() => syncPreviewHost(host)).catch(() => {});
  return controller;
}

function syncPreviewHosts() {
  for (const host of document.querySelectorAll(".gallery .media-host, .quick-rail .media-host, #videoSpotlightPlayer")) {
    syncPreviewHost(host);
  }
}

function syncPreviewHost(host) {
  const controller = previewControllers.get(host);
  if (!controller) return;

  controller.setSpeed?.(Number(speed.value));
  controller.setLoop?.(loop.checked);

  const shouldPlay = autoplay.checked && host.dataset.previewActive === "true" && host.dataset.visible === "true";
  if (shouldPlay) controller.play?.();
  if (!shouldPlay) {
    controller.pause?.();
    controller.showPoster?.();
  }
}

function bindPreviewFocusPlayback(host, motion) {
  const target = host.closest(".preview") || host.closest(".quick-card") || host;
  const activate = () => {
    host.dataset.previewActive = "true";
    ensurePreviewController(host, motion);
    syncPreviewHost(host);
  };
  const deactivate = () => {
    host.dataset.previewActive = "false";
    syncPreviewHost(host);
  };

  target.addEventListener("pointerenter", activate);
  target.addEventListener("pointerleave", deactivate);
  target.addEventListener("focusin", activate);
  target.addEventListener("focusout", deactivate);
}

async function openDetail(motion) {
  activeMotion = motion;
  const title = getMotionTitle(motion);
  detailTitle.textContent = title;
  detailPath.textContent = motion.file;
  detailPath.title = motion.file;
  stopTimelineLoop();
  resetTimeline();
  detailResolution.textContent = "--";
  detailController?.destroy?.();
  detailController = null;
  detailHost.replaceChildren();
  detailOpen.href = motion.file;
  detailDownload.href = motion.file;
  detailDownload.download = getDownloadName(motion);
  detailHost.dataset.kind = motion.kind;
  setupWebDetail(motion, () => detailController);
  detailTags.replaceChildren();

  const tags = (isInteractiveKind(motion.kind) ? [motion.category, motion.interactionType] : [motion.kindLabel || labelForKind(motion.kind), motion.category, motion.interactionType, ...(motion.tags || [])]).filter(Boolean);
  for (const tag of tags) {
    const node = document.createElement("span");
    node.textContent = tag;
    detailTags.append(node);
  }

  detailDialog.showModal();
  updateDetailInfo(motion);
  await nextFrame();
  if (!detailDialog.open || activeMotion !== motion) return;
  detailController = createMediaController(detailHost, motion, { detail: true });
  const controller = detailController;
  syncDetailPlayer();
  await controller.ready?.();
  if (!detailDialog.open || activeMotion !== motion || detailController !== controller) return;
  await updateDetailInfo(motion);
  detailController.play?.();
  if (!isInteractiveKind(motion.kind)) startTimelineLoop();
}

function createMediaController(host, motion, options = {}) {
  host.replaceChildren();
  if (isInteractiveKind(motion.kind)) return createWebController(host, motion, options);
  if (motion.kind === "lottie") return createLottieController(host, motion, options);
  if (motion.kind === "gif") return createImageController(host, motion);
  if (motion.kind === "hevc" || motion.kind === "video") return createVideoController(host, motion, options);
  if (motion.kind === "rive") return createRiveController(host, motion);
  return createFallbackController(host, motion);
}

function createLottieController(host, motion, options = {}) {
  const player = document.createElement("lottie-player");
  player.setAttribute("background", "transparent");
  player.setAttribute("loading", "lazy");
  player.setAttribute("src", motion.file);
  host.append(player);
  let animationItem = null;

  const showPoster = () => {
    if (!animationItem || options.detail) return;
    const totalFrames = Number(animationItem.totalFrames) || Number(animationItem.animationData?.op) || 0;
    const frame = Math.max(1, Math.floor(totalFrames * previewPosterFrameRatio));
    animationItem.goToAndStop(frame, true);
  };

  const ready = async () => {
    if (typeof player.load === "function") {
      try {
        await player.load(motion.file);
      } catch {
        player.setAttribute("src", motion.file);
      }
    }

    try {
      if (typeof player.getLottie === "function") animationItem = await player.getLottie();
      showPoster();
    } catch {
      animationItem = null;
    }
  };

  const readyPromise = ready();
  return {
    element: player,
    ready: () => readyPromise,
    play: () => player.play?.(),
    pause: () => player.pause?.(),
    showPoster,
    setLoop: (value) => player.toggleAttribute("loop", value),
    setSpeed: (value) => player.setSpeed?.(value),
    seek: (frame) => animationItem?.goToAndStop?.(frame, true) || player.seek?.(frame),
    getFrame: () => Number(animationItem?.currentFrame || 0),
    destroy: () => player.pause?.(),
  };
}

function createImageController(host, motion) {
  const image = document.createElement("img");
  image.src = motion.file;
  image.alt = motion.name || filenameToName(motion.file);
  image.loading = "lazy";
  host.append(image);
  return {
    element: image,
    play: () => {},
    pause: () => {},
    showPoster: () => {},
    setLoop: () => {},
    setSpeed: () => {},
    destroy: () => {},
  };
}

function createVideoController(host, motion, options = {}) {
  const video = document.createElement("video");
  video.src = canPlayOriginalVideo(video, motion) ? motion.file : motion.previewFile || motion.file;
  video.muted = true;
  video.playsInline = true;
  video.setAttribute("playsinline", "");
  video.preload = "metadata";
  video.controls = false;
  host.append(video);
  let unsupported = false;
  const showPoster = () => {
    if (!Number.isFinite(video.duration) || options.detail) return;
    video.currentTime = Math.max(0, video.duration * previewPosterFrameRatio);
  };

  const showUnsupported = () => {
    if (unsupported) return;
    unsupported = true;
    host.classList.add("media-error");
    host.append(createFallbackNode("浏览器暂不支持此视频编码", "可尝试 Safari / iOS，或下载原文件"));
  };

  video.addEventListener("loadedmetadata", showPoster, { once: true });
  video.addEventListener("error", showUnsupported);

  return {
    element: video,
    ready: () =>
      new Promise((resolve) => {
        if (Number.isFinite(video.duration) && video.duration > 0) resolve();
        else {
          video.addEventListener("loadedmetadata", resolve, { once: true });
          video.addEventListener("error", resolve, { once: true });
        }
      }),
    play: () => video.play().catch(() => {}),
    pause: () => video.pause(),
    showPoster,
    setLoop: (value) => {
      video.loop = value;
    },
    setSpeed: (value) => {
      video.playbackRate = value;
    },
    seek: (frame) => {
      if (!activeMotionInfo?.frameRate) return;
      video.currentTime = Number(frame) / activeMotionInfo.frameRate;
    },
    getFrame: () => (activeMotionInfo?.frameRate ? video.currentTime * activeMotionInfo.frameRate : 0),
    destroy: () => video.pause(),
  };
}

function canPlayOriginalVideo(video, motion) {
  if (!motion.previewFile) return true;
  const userAgent = navigator.userAgent || "";
  const isSafari = /Safari/i.test(userAgent) && !/Chrome|Chromium|CriOS|Android/i.test(userAgent);
  if (!isSafari) return false;
  return [
    video.canPlayType('video/mp4; codecs="hvc1"'),
    video.canPlayType("video/quicktime"),
  ].some((result) => result === "probably" || result === "maybe");
}

function createRiveController(host, motion) {
  const canvas = document.createElement("canvas");
  canvas.width = 640;
  canvas.height = 640;
  host.append(canvas);
  let riveInstance = null;

  if (window.rive?.Rive) {
    riveInstance = new window.rive.Rive({
      src: motion.file,
      canvas,
      autoplay: false,
      fit: window.rive.Fit?.Contain,
    });
  } else {
    host.replaceChildren(createFallbackNode("Rive 预览器加载失败", "可以打开文件下载查看"));
  }

  return {
    element: canvas,
    play: () => riveInstance?.play?.(),
    pause: () => riveInstance?.pause?.(),
    setLoop: () => {},
    setSpeed: () => {},
    destroy: () => riveInstance?.cleanup?.(),
  };
}

function createFallbackController(host, motion) {
  const node = createFallbackNode(motion.kindLabel || labelForKind(motion.kind), "点击查看可打开完整文件");
  host.append(node);
  return {
    element: node,
    play: () => {},
    pause: () => {},
    setLoop: () => {},
    setSpeed: () => {},
    destroy: () => {},
  };
}

function createFallbackNode(title, subtitle) {
  const node = document.createElement("div");
  node.className = "fallback-preview";
  const strong = document.createElement("strong");
  const span = document.createElement("span");
  strong.textContent = title;
  span.textContent = subtitle;
  node.append(strong, span);
  return node;
}

function syncDetailPlayer() {
  detailSpeedLabel.textContent = `${detailSpeed.value}x`;
  detailController?.setSpeed?.(Number(detailSpeed.value));
  detailController?.setLoop?.(detailLoop.checked);
}

function applyPreviewBackground(value, options = {}) {
  const color = normalizeHexColor(value) || defaultPreviewBackground;
  const label = color.toUpperCase();
  document.documentElement.style.setProperty("--preview-bg", color);
  syncWebBackgrounds();
  previewBg.value = color;
  detailPreviewBg.value = color;
  previewBgLabel.textContent = label;
  detailPreviewBgLabel.textContent = label;

  if (options.persist !== false) {
    localStorage.setItem(previewBackgroundKey, color);
  }
}

function normalizeHexColor(value) {
  const color = String(value || "").trim();
  if (/^#[0-9a-f]{6}$/i.test(color)) return color.toLowerCase();
  if (/^#[0-9a-f]{3}$/i.test(color)) {
    return `#${color[1]}${color[1]}${color[2]}${color[2]}${color[3]}${color[3]}`.toLowerCase();
  }
  return "";
}

async function updateVisibleCardResolution(host, motion) {
  return updateVisibleHostInfo(host, motion);
}

async function updateVisibleHostInfo(host, motion) {
  let info = null;
  try {
    info = await getMotionInfo(motion);
    applyMediaSizing(host, info);
  } catch {
    info = null;
  }

  const resolution = host.closest(".motion-card")?.querySelector(".resolution");
  if (!resolution || resolution.dataset.loaded === "true") return;
  resolution.dataset.loaded = "true";
  if (info) {
    resolution.textContent = `规格 ${formatInfoSummary(info, motion)}`;
  } else {
    resolution.textContent = "规格 未知";
  }
}

async function updateDetailInfo(motion) {
  if (isInteractiveKind(motion.kind)) return;
  try {
    const info = await getMotionInfo(motion);
    if (activeMotion?.file !== motion.file) return;
    applyMediaSizing(detailHost, info);
    applyMotionInfo(info, motion);
    detailResolution.textContent = formatResolution(info);
  } catch {
    if (activeMotion?.file !== motion.file) return;
    resetTimeline("未知");
    detailResolution.textContent = "未知";
  }
}

function applyMediaSizing(host, info) {
  if (!host || !info?.width || !info?.height) return;
  const bounds = getMediaBounds(host);
  const fitted = fitWithin(info.width, info.height, bounds.width, bounds.height);
  host.style.width = `${fitted.width}px`;
  host.style.height = `${fitted.height}px`;
  host.style.setProperty("--media-aspect", `${info.width} / ${info.height}`);
}

function getMediaBounds(host) {
  const detailStage = host.closest(".detail-preview");
  if (detailStage) {
    const rect = detailStage.getBoundingClientRect();
    return {
      width: Math.max(220, Math.min(760, rect.width * 0.94)),
      height: Math.max(220, Math.min(760, rect.height * 0.94)),
    };
  }

  const quickStage = host.closest(".quick-card");
  if (quickStage) {
    const rect = host.getBoundingClientRect();
    return {
      width: Math.max(80, rect.width || 148),
      height: Math.max(70, rect.height || 116),
    };
  }

  const previewStage = host.closest(".preview");
  const rect = previewStage?.getBoundingClientRect();
  return {
    width: Math.max(120, Math.min(230, (rect?.width || 295) * 0.78)),
    height: Math.max(120, Math.min(200, (rect?.height || 214) * 0.78)),
  };
}

function fitWithin(width, height, maxWidth, maxHeight) {
  const scale = Math.min(maxWidth / width, maxHeight / height);
  return {
    width: Math.max(1, Math.round(width * scale)),
    height: Math.max(1, Math.round(height * scale)),
  };
}

async function getMotionInfo(motion) {
  if (motionInfoCache.has(motion.file)) return motionInfoCache.get(motion.file);
  let info;
  if (motion.kind === "lottie") info = await getLottieInfo(motion.file);
  else if (motion.kind === "hevc" || motion.kind === "video") info = await getVideoInfo(motion.previewFile || motion.file);
  else if (motion.kind === "gif") info = await getImageInfo(motion.file);
  else info = { width: 0, height: 0, frames: 0, duration: 0, frameRate: 0 };
  motionInfoCache.set(motion.file, info);
  return info;
}

async function getLottieInfo(file) {
  const response = await fetch(file);
  if (!response.ok) throw new Error("Unable to read lottie json");
  const data = await response.json();
  const frameRate = Number(data.fr) || 0;
  const inPoint = Number(data.ip) || 0;
  const outPoint = Number(data.op) || 0;
  const width = Number(data.w) || 0;
  const height = Number(data.h) || 0;
  const frames = Math.max(0, Math.round(outPoint - inPoint));
  const duration = frameRate > 0 ? frames / frameRate : 0;
  return { frameRate, inPoint, outPoint, width, height, frames, duration };
}

function getVideoInfo(file) {
  return new Promise((resolve, reject) => {
    const video = document.createElement("video");
    video.preload = "metadata";
    video.onloadedmetadata = () => {
      const duration = Number(video.duration) || 0;
      const frameRate = 30;
      resolve({
        width: video.videoWidth || 0,
        height: video.videoHeight || 0,
        frameRate,
        frames: Math.round(duration * frameRate),
        duration,
      });
    };
    video.onerror = reject;
    video.src = file;
  });
}

function getImageInfo(file) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () =>
      resolve({
        width: image.naturalWidth || 0,
        height: image.naturalHeight || 0,
        frames: 0,
        duration: 0,
        frameRate: 0,
      });
    image.onerror = reject;
    image.src = file;
  });
}

function formatInfoSummary(info, motion) {
  const resolution = formatResolution(info);
  if (motion.kind === "lottie" && info.frames) return `${resolution} / ${info.frames.toLocaleString()}帧`;
  if ((motion.kind === "hevc" || motion.kind === "video") && info.duration) return `${resolution} / ${formatSeconds(info.duration)}s`;
  return resolution;
}

function formatResolution(info) {
  if (!info?.width || !info?.height) return "未知";
  return `${Math.round(info.width).toLocaleString()} × ${Math.round(info.height).toLocaleString()}`;
}

function resetTimeline(label = "--") {
  activeMotionInfo = null;
  detailTimeline.disabled = true;
  detailTimeline.min = "0";
  detailTimeline.max = "0";
  detailTimeline.value = "0";
  detailCurrentFrame.textContent = label;
  detailTotalFrames.textContent = label;
  detailCurrentTime.textContent = label;
  detailTotalDuration.textContent = label;
}

function applyMotionInfo(info, motion) {
  activeMotionInfo = info;
  const hasTimeline = (motion.kind === "lottie" || motion.kind === "hevc" || motion.kind === "video") && info.frames > 0;
  detailTimeline.disabled = !hasTimeline;
  detailTimeline.min = "0";
  detailTimeline.max = String(info.frames || 0);
  detailTimeline.value = "0";
  detailTotalFrames.textContent = info.frames ? info.frames.toLocaleString() : "--";
  detailTotalDuration.textContent = info.duration ? `${formatSeconds(info.duration)}s` : "--";
  updateTimelineLabels(0);
}

function updateTimelineLabels(frame) {
  if (!activeMotionInfo) return;
  const safeFrame = Math.min(activeMotionInfo.frames || 0, Math.max(0, Math.round(frame)));
  const currentSeconds = activeMotionInfo.frameRate > 0 ? safeFrame / activeMotionInfo.frameRate : 0;
  detailCurrentFrame.textContent = activeMotionInfo.frames ? safeFrame.toLocaleString() : "--";
  detailCurrentTime.textContent = activeMotionInfo.duration ? `${formatSeconds(currentSeconds)}s` : "--";
  detailTimeline.value = String(safeFrame);
}

function seekDetailFrame(frame) {
  const targetFrame = Number(frame);
  if (!Number.isFinite(targetFrame)) return;

  detailController?.pause?.();
  stopTimelineLoop();
  detailController?.seek?.(targetFrame);
  updateTimelineLabels(targetFrame);
}

function startTimelineLoop() {
  stopTimelineLoop();

  const tick = () => {
    if (activeMotionInfo && detailController?.getFrame) {
      updateTimelineLabels(detailController.getFrame());
    }

    timelineRaf = window.requestAnimationFrame(tick);
  };

  timelineRaf = window.requestAnimationFrame(tick);
}

function stopTimelineLoop() {
  if (!timelineRaf) return;
  window.cancelAnimationFrame(timelineRaf);
  timelineRaf = 0;
}

function nextFrame() {
  return new Promise((resolve) => window.requestAnimationFrame(resolve));
}

function formatSeconds(value) {
  if (!Number.isFinite(value)) return "0.00";
  return value >= 10 ? value.toFixed(1) : value.toFixed(2);
}

function getMotionTitle(motion) {
  const name = String(motion?.name || "").trim();
  if (name && !name.startsWith("@") && !name.includes("feishucdn.com") && !/^\d+$/.test(name)) return name;
  return motion?.fileName || filenameToName(motion?.file || "motion");
}

function filenameToName(file) {
  return file
    .split("/")
    .pop()
    .replace(/\.[^.]+$/i, "")
    .replace(/[-_]+/g, " ");
}

function getDownloadName(motion) {
  if (motion.downloadName) return motion.downloadName;

  try {
    const url = new URL(motion.file, window.location.href);
    return decodeURIComponent(url.pathname.split("/").pop() || "") || `${slugifyFileName(motion.name || "motion")}.json`;
  } catch {
    return String(motion.file || "").split("/").pop() || `${slugifyFileName(motion.name || "motion")}.json`;
  }
}

function slugifyFileName(value) {
  return (
    String(value)
      .trim()
      .replace(/\.[^.]+$/i, "")
      .replace(/[\\/:*?"<>|]+/g, "-")
      .replace(/\s+/g, "-")
      .replace(/-+/g, "-")
      .replace(/^-|-$/g, "")
      .slice(0, 80) || "motion"
  );
}

function addLocalFiles(files) {
  const localItems = [...files]
    .filter((file) => inferKindFromFile(file.name, file.type))
    .map((file) => {
      const kind = inferKindFromFile(file.name, file.type);
      return {
        name: filenameToName(file.name),
        file: URL.createObjectURL(file),
        downloadName: file.name,
        kind,
        kindLabel: labelForKind(kind),
        category: "临时预览",
        tags: ["local"],
        mimeType: file.type,
      };
    });

  motions = [...localItems, ...motions.filter((item) => item.category !== "临时预览")];
  populateKinds();
  populateCategories();
  category.value = "临时预览";
  render();
}

function normalizeKind(value) {
  const text = String(value || "").trim().toLowerCase();
  if (text === "web" || text === "motion") return text;
  if (text.includes("lottie") || text.includes("json") || text.endsWith(".lottie")) return "lottie";
  if (text.includes("hevc") || text.includes("alpha") || text.includes("透明视频") || text.includes("视频动效") || text === "video") return "video";
  if (text.includes("gif") || text.endsWith(".gif")) return "gif";
  if (text.includes("riv") || text.includes("rive") || text.endsWith(".riv")) return "rive";
  if (text.includes("实践") || text.includes("app") || text.includes("交互") || /\.html?$/i.test(text)) return "practice";
  if (/\.(mov|mp4|m4v|webm)$/i.test(text)) return "video";
  return "practice";
}

function inferKindFromFile(name, type = "") {
  const text = `${name} ${type}`.toLowerCase();
  if (text.includes("application/json") || /\.json$/i.test(name) || /\.lottie$/i.test(name)) return "lottie";
  if (text.includes("image/gif") || /\.gif$/i.test(name)) return "gif";
  if (/\.riv$/i.test(name)) return "rive";
  if (/\.html?$/i.test(name)) return "practice";
  if (text.includes("video/") || /\.(mov|mp4|m4v|webm)$/i.test(name)) return "video";
  return "";
}

function labelForKind(kind) {
  return kindLabels[kind] || kind || "实践型动效";
}

function formatDescription(kind) {
  return {
    lottie: "JSON / dotLottie",
    video: "MOV / MP4 / HEVC / Alpha",
    gif: "轻量循环图",
    rive: "状态机与交互动画",
    practice: "App 内交互原型",
    web: "可交互 / 调参 / 复制代码",
    motion: "弹簧 / 手势 / 时间线 / SVG",
  }[kind] || "自定义格式";
}

function moduleIcon(kind) {
  return {
    lottie: "L",
    gif: "G",
    rive: "R",
    practice: "P",
    video: "V",
    web: "W",
    motion: "M",
  }[kind] || "M";
}

function getOrderedKinds(counts) {
  const order = ["lottie", "video", "gif", "rive", "practice", "web", "motion"];
  return Object.keys(counts).sort((a, b) => {
    const left = order.indexOf(a);
    const right = order.indexOf(b);
    if (left !== -1 || right !== -1) return (left === -1 ? 999 : left) - (right === -1 ? 999 : right);
    return labelForKind(a).localeCompare(labelForKind(b), "zh-Hans-CN");
  });
}

function countBy(list, getter) {
  return list.reduce((result, item) => {
    const key = getter(item);
    result[key] = (result[key] || 0) + 1;
    return result;
  }, {});
}

function updateFormatActiveState() {
  for (const button of formatNav.querySelectorAll(".format-button")) {
    button.classList.toggle("active", button.dataset.kind === kindSelect.value);
  }
}

search.addEventListener("input", render);
homeTrigger.addEventListener("click", showHome);
homePrimaryCta.addEventListener("click", () => enterModule("all"));
homeSecondaryCta.addEventListener("click", () => enterModule("lottie"));
kindSelect.addEventListener("change", () => {
  enterModule(kindSelect.value);
});
category.addEventListener("change", render);
refresh.addEventListener("click", loadManifest);

speed.addEventListener("input", () => {
  speedLabel.textContent = `${speed.value}x`;
  syncPreviewHosts();
});

previewBg.addEventListener("input", (event) => applyPreviewBackground(event.target.value));
autoplay.addEventListener("change", syncPreviewHosts);
loop.addEventListener("change", syncPreviewHosts);
fileInput.addEventListener("change", (event) => addLocalFiles(event.target.files));
detailClose.addEventListener("click", () => detailDialog.close());
detailPlay.addEventListener("click", () => {
  if (isInteractiveKind(activeMotion?.kind)) { detailController?.replay?.(); return; }
  detailController?.play?.();
  startTimelineLoop();
});
detailPause.addEventListener("click", () => {
  detailController?.pause?.();
  stopTimelineLoop();
});
detailSpeed.addEventListener("input", syncDetailPlayer);
detailLoop.addEventListener("change", syncDetailPlayer);
detailPreviewBg.addEventListener("input", (event) => applyPreviewBackground(event.target.value));
detailTimeline.addEventListener("input", (event) => seekDetailFrame(event.target.value));

detailCopy.addEventListener("click", async () => {
  if (!activeMotion) return;
  if (isInteractiveKind(activeMotion.kind)) { await copyExample(detailCopy, activeMotion, getWebValues()); return; }
  await navigator.clipboard.writeText(activeMotion.file);
  detailCopy.textContent = "已复制";
  window.setTimeout(() => {
    detailCopy.textContent = "复制路径";
  }, 1100);
});

detailDownload.addEventListener("click", (event) => {
  if (!isInteractiveKind(activeMotion?.kind)) return;
  event.preventDefault();
  downloadExample(activeMotion, getWebValues());
});

detailDialog.addEventListener("click", (event) => {
  if (event.target === detailDialog) detailDialog.close();
});

detailDialog.addEventListener("close", () => {
  detailController?.pause?.();
  detailController?.destroy?.();
  detailController = null;
  stopTimelineLoop();
});

dropzone.addEventListener("dragover", (event) => {
  event.preventDefault();
  dropzone.classList.add("active");
});

dropzone.addEventListener("dragleave", () => dropzone.classList.remove("active"));

dropzone.addEventListener("drop", (event) => {
  event.preventDefault();
  dropzone.classList.remove("active");
  addLocalFiles(event.dataTransfer.files);
});

document.querySelectorAll(".tab").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelector(".tab.active").classList.remove("active");
    button.classList.add("active");
    gallery.classList.toggle("list", button.dataset.view === "list");
  });
});

loadManifest().then(() => { if (["#web", "#motion"].includes(location.hash)) enterModule(location.hash.slice(1)); });
window.setInterval(loadManifest, 30000);
