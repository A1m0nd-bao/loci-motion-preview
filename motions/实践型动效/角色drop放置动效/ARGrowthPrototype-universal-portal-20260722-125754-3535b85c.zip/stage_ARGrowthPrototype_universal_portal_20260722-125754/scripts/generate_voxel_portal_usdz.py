import math
import shutil
import subprocess
from pathlib import Path

from pxr import Gf, Sdf, Usd, UsdGeom, UsdShade


OUT_DIR = Path("/Users/baotianrong/Documents/Codex/2026-07-01/w/outputs/VoxelPortalModel")
BUILD_DIR = OUT_DIR / "usdz_build"
USDC_PATH = BUILD_DIR / "voxel_ground_portal.usdc"
USDZ_PATH = OUT_DIR / "voxel_ground_portal.usdz"


MATERIALS = {
    "outer": ((0.105, 0.115, 0.112), (0.0, 0.0, 0.0), 0.88),
    "outer_top": ((0.155, 0.17, 0.165), (0.0, 0.0, 0.0), 0.84),
    "inner_deep": ((0.015, 0.16, 0.34), (0.0, 0.08, 0.26), 0.62),
    "inner_mid": ((0.02, 0.32, 0.54), (0.0, 0.18, 0.42), 0.55),
    "inner_bright": ((0.06, 0.54, 0.66), (0.0, 0.36, 0.52), 0.48),
    "inner_core": ((0.12, 0.82, 0.82), (0.0, 0.85, 0.82), 0.38),
    "inner_shadow": ((0.012, 0.09, 0.2), (0.0, 0.03, 0.16), 0.68),
    "pixel_light": ((0.18, 0.92, 0.82), (0.0, 0.95, 0.75), 0.36),
    "pixel_green": ((0.16, 0.72, 0.42), (0.0, 0.32, 0.16), 0.52),
    "pixel_blue": ((0.025, 0.38, 0.78), (0.0, 0.24, 0.65), 0.52),
    "wall_deep": ((0.018, 0.23, 0.29), (0.0, 0.35, 0.48), 0.7),
    "wall_highlight": ((0.025, 0.46, 0.52), (0.0, 0.65, 0.78), 0.62),
    "edge": ((0.1, 1.0, 0.42), (0.0, 2.65, 0.42), 0.3),
    "edge_core": ((0.42, 1.0, 0.48), (0.08, 3.05, 0.38), 0.24),
    "particle": ((0.08, 0.88, 1.0), (0.0, 0.95, 1.7), 0.34),
    "particle_small": ((0.06, 0.46, 1.0), (0.0, 0.28, 1.25), 0.38),
}


INNER_ROWS = {
    -5: range(-2, 3),
    -4: range(-5, 5),
    -3: range(-6, 6),
    -2: range(-7, 7),
    -1: range(-7, 8),
    0: range(-7, 8),
    1: range(-6, 7),
    2: range(-6, 6),
    3: range(-5, 6),
    4: range(-4, 5),
    5: range(-2, 4),
}

NOTCHES = {
    (-7, -1), (-6, -3), (-5, 4), (-4, -4), (-2, 5),
    (1, -5), (3, 5), (5, 3), (6, -2), (7, 0),
}

EXTRAS = {
    (-9, -3), (-9, 0), (-8, 3), (-7, 5), (-5, -6), (-3, 6), (0, 7),
    (3, 6), (6, 5), (8, 2), (9, -1), (8, -4), (5, -6), (1, -7),
    (-2, -7), (-6, -5),
}

PARTICLES = [
    (-0.88, 0.32, -0.45, 0.07), (-0.68, 0.42, -0.56, 0.035), (-0.56, 0.22, 0.58, 0.052),
    (-0.42, 0.52, 0.42, 0.068), (-0.24, 0.26, -0.72, 0.038), (-0.08, 0.48, 0.68, 0.048),
    (0.18, 0.28, -0.62, 0.054), (0.34, 0.55, 0.50, 0.04), (0.56, 0.34, -0.42, 0.074),
    (0.78, 0.42, 0.32, 0.058), (0.94, 0.22, -0.18, 0.045), (-1.03, 0.18, 0.08, 0.042),
    (1.08, 0.28, 0.08, 0.086), (-0.98, 0.46, 0.34, 0.052), (0.04, 0.58, -0.16, 0.04),
    (0.66, 0.18, 0.64, 0.032), (-0.18, 0.16, 0.82, 0.032), (0.88, 0.50, -0.52, 0.036),
]


def make_material(stage, name, base, emissive, roughness):
    material = UsdShade.Material.Define(stage, f"/World/Looks/{name}")
    shader = UsdShade.Shader.Define(stage, f"/World/Looks/{name}/PreviewSurface")
    shader.CreateIdAttr("UsdPreviewSurface")
    shader.CreateInput("diffuseColor", Sdf.ValueTypeNames.Color3f).Set(Gf.Vec3f(*base))
    shader.CreateInput("emissiveColor", Sdf.ValueTypeNames.Color3f).Set(Gf.Vec3f(*emissive))
    shader.CreateInput("roughness", Sdf.ValueTypeNames.Float).Set(float(roughness))
    shader.CreateInput("metallic", Sdf.ValueTypeNames.Float).Set(0.0)
    material.CreateSurfaceOutput().ConnectToSource(shader.ConnectableAPI(), "surface")
    return material


def is_inner_cell(x, z):
    return z in INNER_ROWS and x in INNER_ROWS[z] and (x, z) not in NOTCHES


def boundary_edges(inner_cells):
    edges = []
    for x, z in inner_cells:
        for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            if (x + dx, z + dz) not in inner_cells:
                edges.append((x, z, dx, dz))
    return edges


def nearest_distance(cell, cells):
    return min(math.hypot(cell[0] - x, cell[1] - z) for x, z in cells)


def outer_cells(inner_cells, edges):
    cells = set()
    for x, z, dx, dz in edges:
        for ring in range(1, 4):
            cell = (x + dx * ring, z + dz * ring)
            if cell not in inner_cells and -10 <= cell[0] <= 10 and -8 <= cell[1] <= 8:
                cells.add(cell)
    cells |= EXTRAS
    return {cell for cell in cells if nearest_distance(cell, inner_cells) < 3.25 or cell in EXTRAS}


def positive_mod(value, divisor):
    return value % divisor


class CubeWriter:
    def __init__(self, stage, materials):
        self.stage = stage
        self.materials = materials
        self.index = 0

    def add_cube(self, name, size, center, material_name):
        path = f"/World/{name}_{self.index:04d}"
        self.index += 1

        xform = UsdGeom.Xform.Define(self.stage, path)
        xform.AddTranslateOp().Set(Gf.Vec3d(*center))
        xform.AddScaleOp().Set(Gf.Vec3f(*size))

        cube = UsdGeom.Cube.Define(self.stage, f"{path}/Cube")
        cube.CreateSizeAttr(1.0)
        UsdShade.MaterialBindingAPI(cube.GetPrim()).Bind(self.materials[material_name])


def add_edge_box(writer, name, edge, cell, thickness, height, y, material_name):
    x, z, dx, dz = edge
    if dx != 0:
        writer.add_cube(
            name,
            (thickness, height, cell * 0.92),
            ((x + 0.5 * dx) * cell, y, z * cell),
            material_name,
        )
    else:
        writer.add_cube(
            name,
            (cell * 0.92, height, thickness),
            (x * cell, y, (z + 0.5 * dz) * cell),
            material_name,
        )


def add_inner_pixel_chips(writer, x, z, cell, base_height, normalized_radius):
    chip_rule = positive_mod(x * 13 + z * 7, 5)
    if chip_rule not in (0, 2) and normalized_radius >= 0.42:
        return

    widths = [0.22, 0.30, 0.38, 0.48]
    depths = [0.20, 0.28, 0.36, 0.46]
    offsets = [-0.26, -0.12, 0.12, 0.26]
    chip_count = 2 if normalized_radius < 0.42 and chip_rule != 1 else 1

    for index in range(chip_count):
        seed = abs(x * 41 + z * 67 + index * 13)
        width = cell * widths[seed % len(widths)]
        depth = cell * depths[(seed // 3) % len(depths)]
        offset_x = offsets[(seed // 5) % len(offsets)] * cell
        offset_z = offsets[(seed // 7) % len(offsets)] * cell

        if normalized_radius < 0.34:
            material = "pixel_light"
        elif chip_rule == 0 and z > 0:
            material = "pixel_green"
        elif chip_rule == 2 and x < 2:
            material = "pixel_blue"
        else:
            material = "inner_bright"

        writer.add_cube(
            "portal_inner_pixel_chip",
            (width, 0.005, depth),
            (x * cell + offset_x, 0.002 + base_height + 0.006 + index * 0.002, z * cell + offset_z),
            material,
        )

    if normalized_radius > 0.72 and (x * 5 - z * 9) % 4 == 0:
        inset = cell * 0.56
        writer.add_cube(
            "portal_inner_shadow_inset",
            (inset, 0.004, inset),
            (x * cell, 0.002 + base_height + 0.004, z * cell),
            "inner_shadow",
        )


def build_usd():
    if BUILD_DIR.exists():
        shutil.rmtree(BUILD_DIR)
    BUILD_DIR.mkdir(parents=True)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    if USDZ_PATH.exists():
        USDZ_PATH.unlink()

    stage = Usd.Stage.CreateNew(str(USDC_PATH))
    UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.y)
    UsdGeom.SetStageMetersPerUnit(stage, 1.0)
    world = UsdGeom.Xform.Define(stage, "/World")
    stage.SetDefaultPrim(world.GetPrim())
    UsdGeom.Scope.Define(stage, "/World/Looks")

    materials = {
        name: make_material(stage, name, base, emissive, roughness)
        for name, (base, emissive, roughness) in MATERIALS.items()
    }
    writer = CubeWriter(stage, materials)

    cell = 0.1116
    gap = 0.0094
    inner_cells = {(x, z) for z in range(-6, 7) for x in range(-8, 9) if is_inner_cell(x, z)}
    edges = boundary_edges(inner_cells)
    outer = outer_cells(inner_cells, edges)

    for x, z in sorted(inner_cells):
        normalized_radius = math.hypot(x / 7.2, z / 5.1)
        height = 0.0158 if (x * 17 + z * 11) % 3 == 0 else 0.0086
        wave = math.sin(x * 1.4 + z * 1.9) + math.cos(x * 0.8 - z * 1.2)
        if normalized_radius > 0.86:
            material = "inner_shadow" if wave < 0.8 else "inner_deep"
        elif normalized_radius < 0.34 and wave > -0.2:
            material = "inner_core"
        else:
            material = "inner_bright" if wave > 1.05 else "inner_mid" if wave > -0.45 else "inner_deep"

        writer.add_cube(
            "portal_inner_tile",
            (cell - gap, height, cell - gap),
            (x * cell, 0.002 + height / 2, z * cell),
            material,
        )
        add_inner_pixel_chips(writer, x, z, cell, height, normalized_radius)

    for x, z in sorted(outer):
        distance = nearest_distance((x, z), inner_cells)
        height = 0.0756 if distance < 1.3 else 0.0518 if distance < 2.15 else 0.0324
        material = "outer_top" if (x * 5 + z * 3) % 7 == 0 else "outer"
        writer.add_cube(
            "portal_outer_block",
            (cell - gap, height, cell - gap),
            (x * cell, height / 2, z * cell),
            material,
        )
        if distance < 2.2 and (x * 19 + z * 23) % 5 == 0:
            writer.add_cube(
                "portal_outer_chip",
                (cell * 0.68, 0.013, cell * 0.68),
                (x * cell, height + 0.0065, z * cell),
                "outer_top",
            )

    for edge in edges:
        x, z, dx, dz = edge
        wall_material = "wall_highlight" if (x + z) % 2 == 0 else "wall_deep"
        add_edge_box(writer, "portal_inner_wall", edge, cell, 0.018, 0.158, -0.065, wall_material)
        add_edge_box(writer, "portal_glow_edge", edge, cell, 0.0245, 0.020, 0.092, "edge")
        if (x + z + dx - dz) % 2 == 0:
            add_edge_box(writer, "portal_glow_core", edge, cell, 0.0085, 0.0085, 0.109, "edge_core")

    for index, (x, y, z, size) in enumerate(PARTICLES):
        material = "particle_small" if size <= 0.045 else "particle"
        writer.add_cube("portal_particle", (size, size, size), (x, y, z), material)

    stage.GetRootLayer().Save()
    subprocess.run(["usdzip", str(USDZ_PATH), str(USDC_PATH)], check=True)
    print(USDZ_PATH)


if __name__ == "__main__":
    build_usd()
