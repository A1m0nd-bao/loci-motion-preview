# iOS AR Scan Effect Handoff

This package is the iOS handoff for the cyan translucent scan effect.

Important: this is not a USDZ-only effect. USDZ is used as model data. The translucent material, simple edge glow, scan reveal, and animated glowing mesh are runtime rendering effects and should be implemented in the iOS app with RealityKit custom materials or an equivalent Metal pipeline.

## Contents

- `Assets/new_body_model.usdz`  
  Converted from `/Users/baotianrong/Downloads/new.usdc` with its referenced texture packaged for iOS/RealityKit loading.

- `Assets/user_wire_grid.usdz`  
  Converted from the user-provided wireframe asset. The sample uses this user wireframe for the scan reveal instead of generated mesh edges.

- `Sources/ScanARView.swift`  
  SwiftUI wrapper for the RealityKit AR preview.

- `Sources/ScanEffectController.swift`  
  Loads the USDZ assets, applies custom materials, constrains the body to a 1m target height, aligns the feet to y=0, and animates the scan band.

- `Sources/ScanMaterials.swift`  
  RealityKit material setup.

- `Sources/ScanEffectShaders.metal`  
  Runtime material shaders for cyan translucency, Fresnel-like rim glow, and scan-band grid reveal.

## Integration

Open `ScanEffectARApp.xcodeproj` in Xcode to inspect or run the minimal sample app.

1. Add both USDZ files from `Assets` to the iOS app target.
2. Add the Swift files and `ScanEffectShaders.metal` to the same app target.
3. Use `ScanARView()` from SwiftUI, or call `ScanEffectController.install(in:)` with an existing `ARView`.
4. Confirm that the model is loaded in an actual app AR session, not only in Quick Look.

## Verification

The included Xcode project was build-checked with Xcode 26.4.1 using the iOS Simulator SDK:

```sh
xcodebuild -project ScanEffectARApp.xcodeproj -scheme ScanEffectAR -sdk iphonesimulator -configuration Debug CODE_SIGNING_ALLOWED=NO build
```

This verifies source and shader compilation. Final AR placement, camera permission, visual brightness, and material tuning still need an iPhone/iPad AR test.

## Reality Check

Quick Look can preview the USDZ model, but it should not be treated as the final renderer for this effect. Quick Look may drop custom shader logic, bloom, Fresnel behavior, and USD curve lines. The intended production path is:

`USDZ model assets + RealityKit/Metal runtime material + app-side scan animation`

If the development team is restricted to opening a plain USDZ in Quick Look only, the effect must be simplified to static transparency/emission and cannot match the browser preview.

The current sample uses RealityKit `CustomMaterial` with Metal shaders for:

- translucent cyan body material
- view-dependent Fresnel-style rim emission
- user-provided wireframe scan reveal
- emissive cyan scan lines
- runtime 1m height fit and foot-to-ground alignment

If the body looks less vivid than the scan lines on a real iOS AR camera feed, tune `bodyColor` and the `bodyColor * 0.42h` emissive fill in `ScanEffectShaders.metal`. The scan lines are unlit/emissive, while the body is transparent and blended over the camera feed, so they will not read identically without this compensation.
