import SwiftUI

@main
struct ARGrowthPrototypeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
