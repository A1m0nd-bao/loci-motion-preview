# 奖励票券 · 红金南瓜弹跳

独立条目 `sipplay-reward-ticket-pumpkin`。这不是 `sipplay-reward-ticket`（166×36 邀请奖励卡券），也不是 `sipplay-reward-ticket-harvest`（已上线的红金 Ease-Out 轻弹）。两条旧票券都不改。

打开 `reward-ticket-pumpkin.html` 即可离线播放。画面、南瓜、吊牌和飘带都在这一个文件里，没有外部脚本、图片或字体文件。自定义元素名是 `sipplay-reward-ticket`，`variant="harvest"`。它和另外两份票券运行时用了同一个元素名，所以要单独打开这个文件，不要和它们写进同一个页面。

可选 `?compact` 进入 260×220 目录缩略图。不加这个参数时，页面就是交付的红金票预览。

- **字节**: `70663`
- **SHA256**: `bb8c896677af452a003810d60990b30ecc52c7031ee02e2f41affa4135f6963d`

```html
<sipplay-reward-ticket
  id="harvest-ticket"
  variant="harvest"
  label="红金南瓜奖励票卡"
  ribbon-duration="1.36">
</sipplay-reward-ticket>
```

元素定义写在同一个 HTML 里。没有单独的外部脚本，也没有额外运行库。

## 尺寸

票面是 **167×36**。`:host([variant="harvest"])` 把宽度设成 167px，SVG 的 `viewBox` 也是 `0 0 167 36`。预览页默认把票放大 **2.15** 倍（视口窄于 520px 时是 **1.85** 倍）。目录缩略图用 **1.4** 倍，放在 260×220 里。

## 动效

- **常态**: 星点、金线微光，飘带上有一条循环流光。南瓜和吊牌静止。
- **南瓜**: 一次操作只有一跳。先轻压蓄力，再起跳，到一个顶点，落地时轻轻压扁，然后停住。落地后不再跳第二下，身体也不再来回晃。仍保留一点挤压和拉长。默认跟随 `duration`，下限 800ms，未设置时是 **850ms**。茎和叶留在 `.harvest-art` 里。
- **吊牌**: `.harvest-tag` 跟着轻轻摆一下，大约从 **+1.5°** 到 **-5.5°**，再回到原位。没有来回多摆。
- **飘带**: `ribbon-duration` 默认 **1.36s**（限制 0.4–6）。可见段全程 `easeOutCubic`，长满后停住。
- **同一次操作**: 悬停后马上点击，或 Enter 接着触发 click，都算一次。只跳一下，也不会把飘带再排一轮。
- **再点**: 距上次触发超过约 400ms 时，会停掉当前这一下，从头重开一跳。不会等这一下结束再自动补一跳。
- **慢速**: 页面上的「慢速查看路径」把 `duration` 设为 1.7、`ribbon-duration` 设为 2.4。还是同一跳，只是变慢。
- **结束**: 飘带 `stroke-dashoffset` 回到 0，`playing` 去掉，抛出 `motion-finish`。页面状态从「飘带绕行中」回到「就绪」。被重开的那一下不会再抛一次结束。
- **`prefers-reduced-motion: reduce`**: 不开始弹跳、吊牌、飘带生长和流光；星星的 CSS 动画也会停。

可调用 `play()`、`pause()`、`resume()`、`finish()`。开始与结束分别抛出 `motion-start`、`motion-finish`。

## 浏览器核对

在 Chrome 里量过，不是逐帧验收。

- 原生 **167×36**：SVG 边框就是 167×36。850ms 这一跳每 10ms 取样，包围盒顶边只有 **一个** 高点，在 460ms，离票顶 **1.30px**。茎尖（`#94532B` 一带上色）在这一帧离票顶 **1.83px**。高点之后没有再升高。吊牌四边最近 **4.26px**。茎和吊牌都在 167×36 里面。
- 慢速 `duration` 1.7s：同一条曲线拉长到 1700ms，高点仍是 **一个**，在 920ms。飘带 2.4s 结束后 `running` 为 false，虚线偏移为 `0px`。
- 2.15× 的 SVG 是 359.05×77.4，1.85×（375px 宽）是 308.95×66.6，1.4× 缩略图是 233.8×50.4。本地间隙与 1× 相同，三档都落在面板里面。
- 悬停后 30ms 再点击：`motion-start` 1 次，`motion-finish` 1 次，没有排队。
- Enter 后马上再触发 click：同样是 1 次开始、1 次结束。
- 重播按钮：1 次开始、1 次结束，状态回到「就绪」，虚线偏移为 `0px`。
- 播放 520ms 后再触发：开始 2 次（第二下重开），结束 1 次，虚线偏移为 `0px`。
- `prefers-reduced-motion: reduce` 下，播放、悬停、Enter 和重播都不启动。没有弹跳，没有飘带流光，星星动画名为 `none`。

## 文件

- `index.html`：站点预览。与下载文件字节相同，支持 `?compact`。
- `reward-ticket-pumpkin.html`：下载用的同一份 HTML。
- `USAGE.md`：本接入说明。
- `source.zip`：包含以上文件。
