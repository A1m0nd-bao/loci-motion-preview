import Foundation
import simd

public struct ScanEffectConfig {
    public var bodyColor = SIMD3<Float>(0.08, 1.0, 0.74)
    public var rimColor = SIMD3<Float>(0.92, 1.0, 0.92)
    public var gridColor = SIMD3<Float>(0.10, 0.98, 0.78)
    public var bodyOpacity: Float = 0.38
    public var rimStrength: Float = 2.45
    public var gridIntensity: Float = 3.6
    public var scanHeight: Float = 0.065
    public var scanSpeed: Float = 0.72
    public var rotationSpeed: Float = 0.0
    public var targetModelHeight: Float = 1.0
    public var previewScaleMultiplier: Float = 1.0
    public var groundLineLength: Float = 1.2
    public var groundLineThickness: Float = 0.006

    public init() {}
}
